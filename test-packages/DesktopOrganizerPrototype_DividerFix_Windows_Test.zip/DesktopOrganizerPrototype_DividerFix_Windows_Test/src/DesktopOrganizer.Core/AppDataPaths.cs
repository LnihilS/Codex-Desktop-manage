namespace DesktopOrganizer.Core;

public static class AppDataPaths
{
    public static string Root => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "DesktopOrganizer");

    public static string LayoutPath => Path.Combine(Root, "layout.json");
    public static string RecoveryDirectory => Path.Combine(Root, "Recovery");
    public static string ActiveRecoveryPath => Path.Combine(RecoveryDirectory, "active.json");
    public static string PreviousRecoveryPath => Path.Combine(RecoveryDirectory, "previous-valid.json");
    public static string RecoveryHistoryDirectory => Path.Combine(RecoveryDirectory, "History");
    public static string DiagnosticsDirectory => Path.Combine(Root, "Diagnostics");

    public static void EnsureDirectories()
    {
        Directory.CreateDirectory(Root);
        Directory.CreateDirectory(RecoveryDirectory);
        Directory.CreateDirectory(RecoveryHistoryDirectory);
        Directory.CreateDirectory(DiagnosticsDirectory);
    }
}
