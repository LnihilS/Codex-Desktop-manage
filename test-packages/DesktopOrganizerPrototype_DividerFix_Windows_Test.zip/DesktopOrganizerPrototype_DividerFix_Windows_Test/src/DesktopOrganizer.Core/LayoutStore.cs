using System.Text.Json;

namespace DesktopOrganizer.Core;

public static class LayoutStore
{
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true, PropertyNameCaseInsensitive = true };

    public static LayoutDocument Load(out string? warning) => Load(AppDataPaths.LayoutPath, out warning);

    public static LayoutDocument Load(string path, out string? warning)
    {
        warning = null;
        try
        {
            if (!File.Exists(path)) return CreateDefault();
            var json = File.ReadAllText(path);
            var document = JsonSerializer.Deserialize<LayoutDocument>(json, JsonOptions);
            if (document is null || document.SchemaVersion != 1)
            {
                warning = "布局文件为空或版本不受支持。原文件已保留，当前使用临时默认布局。";
                return CreateDefault();
            }
            document.Shortcuts ??= [];
            document.FileReferences ??= [];
            document.Todos ??= [];
            return document;
        }
        catch (Exception ex)
        {
            warning = $"读取布局失败：{ex.GetType().Name}。原文件已保留，当前使用临时默认布局。";
            return CreateDefault();
        }
    }

    public static void Save(LayoutDocument document) => Save(document, AppDataPaths.LayoutPath);

    public static void Save(LayoutDocument document, string path)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path))!);
        var temp = path + ".tmp-" + Guid.NewGuid().ToString("N");
        try
        {
            using (var stream = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None, 4096, FileOptions.WriteThrough))
            {
                JsonSerializer.Serialize(stream, document, JsonOptions);
                stream.Flush(flushToDisk: true);
            }
            var check = JsonSerializer.Deserialize<LayoutDocument>(File.ReadAllText(temp), JsonOptions);
            if (check is null || check.SchemaVersion != 1) throw new InvalidDataException("布局文件写入后校验失败。");
            File.Move(temp, path, overwrite: true);
        }
        finally
        {
            try { if (File.Exists(temp)) File.Delete(temp); } catch { /* best effort cleanup of app-owned temp file */ }
        }
    }

    private static LayoutDocument CreateDefault() => new()
    {
        NeonEnabled = true,
        City = "成都",
        Shortcuts =
        [
            new ShortcutEntry { Name = "文件资源管理器", Path = "explorer.exe", Icon = "📁" },
            new ShortcutEntry { Name = "Microsoft Edge", Path = "msedge.exe", Icon = "🌐" },
            new ShortcutEntry { Name = "Windows 终端", Path = "wt.exe", Icon = "⌘" }
        ],
        Todos =
        [
            new TodoEntry { Text = "整理今天的任务" },
            new TodoEntry { Text = "检查项目进度" },
            new TodoEntry { Text = "留出专注时间" }
        ]
    };
}
