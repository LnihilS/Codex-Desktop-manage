namespace DesktopOrganizer.Core;

// Coordinates are splitter CENTRES, in DesktopGrid device-independent pixels (not local ratios).
public sealed class DividerLayoutState
{
    public double Width { get; set; }
    public double Height { get; set; }
    public Dictionary<string, double> Positions { get; set; } = new();
    public List<DividerLink> Links { get; set; } = new();
}

public sealed record DividerLink(string FirstId, string SecondId);
public enum DividerAxis { Vertical, Horizontal }
public sealed record LayoutBox(double X, double Y, double Width, double Height);
public sealed record DividerSegment(string Id, DividerAxis Axis, double Position, double Start, double End);
public sealed record DividerJunction(string FirstId, string SecondId, double X, double Y, bool Linked);

public sealed class DividerNode
{
    public string Id { get; init; } = "";
    public DividerAxis Axis { get; init; }
    public double Ratio { get; init; } = .5; // Used only to migrate legacy/new nodes.
    public double MinWidth { get; init; } = 70;
    public double MinHeight { get; init; } = 55;
    public DividerNode? First { get; init; }
    public DividerNode? Second { get; init; }
    public bool IsSplit => First is not null && Second is not null;
}

public sealed class DividerLayout
{
    public const double Thickness = 5;
    public const double AlignmentTolerance = 10;
    private const double Epsilon = .0000001;
    private readonly DividerNode _root;
    private readonly Dictionary<string, DividerNode> _nodes = new();
    private readonly Dictionary<string, (double Width, double Height)> _minimums = new();
    public DividerLayoutState State { get; }
    public IReadOnlyDictionary<string, LayoutBox> Boxes => Measure(State.Positions, State.Width, State.Height);
    public (double Width, double Height) MinimumSize => _minimums[_root.Id];

    public DividerLayout(DividerNode root, DividerLayoutState state)
    {
        _root = root;
        State = state;
        State.Positions ??= new();
        State.Links ??= new();
        Index(root);
        // Deleting a split removes only its own stale positions/edges; never binds a replacement by index.
        foreach (var id in State.Positions.Keys.Where(id => !_nodes.ContainsKey(id) || !_nodes[id].IsSplit).ToList())
            State.Positions.Remove(id);
        State.Links.RemoveAll(l => l is null || !IsSplit(l.FirstId) || !IsSplit(l.SecondId)
            || l.FirstId == l.SecondId || _nodes[l.FirstId].Axis != _nodes[l.SecondId].Axis);
    }

    private bool IsSplit(string id) => _nodes.TryGetValue(id, out var n) && n.IsSplit;

    private (double Width, double Height) Index(DividerNode n)
    {
        if (string.IsNullOrWhiteSpace(n.Id) || !_nodes.TryAdd(n.Id, n))
            throw new InvalidDataException("分割线标识为空或重复，已停止布局编辑，未自动重绑线条。");
        var size = (Width: n.MinWidth, Height: n.MinHeight);
        if (n.IsSplit)
        {
            var a = Index(n.First!); var b = Index(n.Second!);
            size = n.Axis == DividerAxis.Vertical
                ? (Math.Max(n.MinWidth, a.Width + Thickness + b.Width), Math.Max(n.MinHeight, Math.Max(a.Height, b.Height)))
                : (Math.Max(n.MinWidth, Math.Max(a.Width, b.Width)), Math.Max(n.MinHeight, a.Height + Thickness + b.Height));
        }
        _minimums.Add(n.Id, size);
        return size;
    }

    public bool Resize(double width, double height, out string message)
    {
        message = "";
        if (!double.IsFinite(width) || !double.IsFinite(height) || width < MinimumSize.Width - Epsilon || height < MinimumSize.Height - Epsilon)
        { message = "桌面区域小于分区树所需最小尺寸；请增大窗口或删除不需要的空白分区。"; return false; }
        var desired = new Dictionary<string, double>();
        Seed(_root, new(0, 0, width, height));
        void Seed(DividerNode node, LayoutBox box)
        {
            if (!node.IsSplit) return;
            var vertical = node.Axis == DividerAxis.Vertical;
            var start = vertical ? box.X : box.Y;
            var extent = vertical ? box.Width : box.Height;
            var oldExtent = vertical ? State.Width : State.Height;
            var coordinate = State.Positions.TryGetValue(node.Id, out var saved) && double.IsFinite(saved) && oldExtent > 0
                ? saved * (vertical ? width : height) / oldExtent
                : start + Thickness / 2 + (extent - Thickness) * Math.Clamp(node.Ratio, 0, 1);
            desired[node.Id] = coordinate;
            // Only seed missing descendants using legal local bounds; projection below handles saved coordinates.
            var minA = vertical ? _minimums[node.First!.Id].Width : _minimums[node.First!.Id].Height;
            var minB = vertical ? _minimums[node.Second!.Id].Width : _minimums[node.Second!.Id].Height;
            var low = start + minA + Thickness / 2; var high = start + extent - minB - Thickness / 2;
            coordinate = Math.Clamp(coordinate, low, Math.Max(low, high));
            var (first, second) = Divide(box, node.Axis, coordinate);
            Seed(node.First!, first); Seed(node.Second!, second);
        }
        if (!FitAxis(DividerAxis.Vertical, width, desired) || !FitAxis(DividerAxis.Horizontal, height, desired)
            || !IsValid(desired, width, height) || !LinksAreAdjacent(desired, width, height))
        { message = "合并关系与分区边界冲突，无法恢复布局；原位置数据保持不变。"; return false; }
        State.Width = width; State.Height = height; State.Positions = desired;
        return true;
    }

    // Difference constraints on explicit groups. Used ONLY for viewport changes/tree edits/legacy migration.
    // Ordinary drags never run this projection or recompute unrelated positions.
    private bool FitAxis(DividerAxis axis, double extent, Dictionary<string, double> desired)
    {
        var group = new Dictionary<string, string>();
        foreach (var id in _nodes.Values.Where(n => n.IsSplit && n.Axis == axis).Select(n => n.Id))
            group[id] = Group(id).Min(StringComparer.Ordinal)!;
        const string start = "$viewport-start", end = "$viewport-end";
        var edges = new List<(string From, string To, double Gap)>();
        void Walk(DividerNode n, string low, double lowOffset, string high, double highOffset)
        {
            if (!n.IsSplit) return;
            if (n.Axis != axis)
            { Walk(n.First!, low, lowOffset, high, highOffset); Walk(n.Second!, low, lowOffset, high, highOffset); return; }
            var id = group[n.Id];
            var minA = axis == DividerAxis.Vertical ? _minimums[n.First!.Id].Width : _minimums[n.First!.Id].Height;
            var minB = axis == DividerAxis.Vertical ? _minimums[n.Second!.Id].Width : _minimums[n.Second!.Id].Height;
            edges.Add((low, id, lowOffset + minA + Thickness / 2));
            edges.Add((id, high, minB + Thickness / 2 - highOffset));
            Walk(n.First!, low, lowOffset, id, -Thickness / 2);
            Walk(n.Second!, id, Thickness / 2, high, highOffset);
        }
        Walk(_root, start, 0, end, 0);
        var ids = group.Values.Append(start).Append(end).Distinct().ToList();
        var degree = ids.ToDictionary(id => id, _ => 0);
        foreach (var edge in edges) degree[edge.To]++;
        var queue = new Queue<string>(ids.Where(id => degree[id] == 0)); var order = new List<string>();
        while (queue.TryDequeue(out var id))
        {
            order.Add(id);
            foreach (var edge in edges.Where(e => e.From == id)) if (--degree[edge.To] == 0) queue.Enqueue(edge.To);
        }
        if (order.Count != ids.Count) return false;
        var lower = ids.ToDictionary(id => id, _ => 0d);
        var upper = ids.ToDictionary(id => id, _ => extent);
        foreach (var id in order)
            foreach (var edge in edges.Where(e => e.From == id)) lower[edge.To] = Math.Max(lower[edge.To], lower[id] + edge.Gap);
        foreach (var id in order.AsEnumerable().Reverse())
            foreach (var edge in edges.Where(e => e.To == id)) upper[edge.From] = Math.Min(upper[edge.From], upper[id] - edge.Gap);
        if (ids.Any(id => lower[id] > upper[id] + Epsilon)) return false;
        var assigned = new Dictionary<string, double> { [start] = 0, [end] = extent };
        foreach (var id in order.Where(id => id != start && id != end))
        {
            var lo = edges.Where(e => e.To == id).Select(e => assigned[e.From] + e.Gap).DefaultIfEmpty(0).Max();
            var wanted = group.Where(g => g.Value == id).Average(g => desired[g.Key]);
            assigned[id] = Math.Clamp(wanted, lo, Math.Max(lo, upper[id]));
        }
        foreach (var (id, g) in group) desired[id] = assigned[g];
        return true;
    }

    public HashSet<string> Group(string id)
    {
        var result = new HashSet<string> { id }; var queue = new Queue<string>(); queue.Enqueue(id);
        while (queue.TryDequeue(out var current))
            foreach (var l in State.Links)
            {
                var next = l.FirstId == current ? l.SecondId : l.SecondId == current ? l.FirstId : null;
                if (next is not null && result.Add(next)) queue.Enqueue(next);
            }
        return result;
    }

    public bool Move(string id, double requested, out string message)
    {
        message = "";
        if (!IsSplit(id) || !State.Positions.TryGetValue(id, out var current) || !double.IsFinite(requested)) return false;
        var moving = Group(id);
        var original = new Dictionary<string, double>(State.Positions);
        Dictionary<string, double> At(double delta)
        {
            var next = new Dictionary<string, double>(original);
            foreach (var member in moving) next[member] += delta;
            return next;
        }
        var delta = requested - current;
        var candidate = At(delta);
        if (!IsValid(candidate, State.Width, State.Height))
        {
            if (!IsValid(original, State.Width, State.Height)) { message = "当前布局无效，已拒绝拖动。"; return false; }
            double lo = 0, hi = 1;
            for (var i = 0; i < 50; i++)
            { var mid = (lo + hi) / 2; if (IsValid(At(delta * mid), State.Width, State.Height)) lo = mid; else hi = mid; }
            candidate = At(delta * lo);
            message = "已到达分区最小尺寸或相邻固定分割线边界；无关分割线保持原位。";
        }
        State.Positions = candidate;
        return true;
    }

    public bool Merge(string firstId, string secondId, out string message)
    {
        message = "";
        if (!Junctions().Any(j => j.FirstId == firstId && j.SecondId == secondId || j.FirstId == secondId && j.SecondId == firstId))
        { message = "这两段线不相邻、方向不同或尚未对齐，未修改合并关系。"; return false; }
        if (Group(firstId).Contains(secondId)) { message = "这两段线已经在同一合并组。"; return false; }
        var original = State.Positions;
        var moving = Group(firstId); moving.UnionWith(Group(secondId));
        Dictionary<string, double> At(double p)
        {
            var next = new Dictionary<string, double>(original);
            foreach (var id in moving) next[id] = p;
            return next;
        }
        // Intersect the exact legal intervals of BOTH groups. An anchor at FirstId may be
        // outside SecondId's interval even though another common coordinate is feasible.
        var atZero = Measure(At(0), State.Width, State.Height);
        var atOne = Measure(At(1), State.Width, State.Height);
        double low = 0, high = _nodes[firstId].Axis == DividerAxis.Vertical ? State.Width : State.Height;
        bool Constrain(double zero, double one, double minimum)
        {
            var slope = one - zero;
            if (Math.Abs(slope) < .000001) return zero >= minimum - Epsilon;
            var bound = (minimum - zero) / slope;
            if (slope > 0) low = Math.Max(low, bound); else high = Math.Min(high, bound);
            return low <= high;
        }
        foreach (var (id, box) in atZero)
        {
            var one = atOne[id]; var minimum = _minimums[id];
            if (!Constrain(box.Width, one.Width, minimum.Width) || !Constrain(box.Height, one.Height, minimum.Height))
            { message = "无法合并：两组线没有共同的合法位置，分区最小尺寸或固定边界冲突。"; return false; }
        }
        var candidate = At(Math.Clamp(original[firstId], low, high));
        if (!IsValid(candidate, State.Width, State.Height))
        { message = "无法合并：对齐会突破分区最小尺寸或其他固定线边界。请先调整空间。"; return false; }
        State.Positions = candidate;
        State.Links.Add(new(firstId, secondId));
        message = "已合并指定两段线；拖动任意一段将同步移动。";
        return true;
    }

    public bool Unmerge(string firstId, string secondId)
        => State.Links.RemoveAll(l => l.FirstId == firstId && l.SecondId == secondId || l.FirstId == secondId && l.SecondId == firstId) > 0;

    public IReadOnlyList<DividerSegment> Segments()
    {
        var boxes = Boxes;
        return _nodes.Values.Where(n => n.IsSplit).Select(n =>
        {
            var b = boxes[n.Id]; return new DividerSegment(n.Id, n.Axis, State.Positions[n.Id],
                n.Axis == DividerAxis.Vertical ? b.Y : b.X, n.Axis == DividerAxis.Vertical ? b.Y + b.Height : b.X + b.Width);
        }).ToList();
    }

    public IReadOnlyList<DividerJunction> Junctions()
    {
        var segments = Segments(); var result = new List<DividerJunction>();
        for (var i = 0; i < segments.Count; i++) for (var k = i + 1; k < segments.Count; k++)
        {
            var a = segments[i]; var b = segments[k];
            if (a.Axis != b.Axis || Math.Abs(a.Position - b.Position) > AlignmentTolerance) continue;
            var before = a.Start < b.Start ? a : b; var after = a.Start < b.Start ? b : a;
            if (Math.Abs(after.Start - before.End - Thickness) > .01) continue;
            var along = (before.End + after.Start) / 2; var across = (a.Position + b.Position) / 2;
            // The joint must lie on an actual perpendicular separator, not across an arbitrary gap.
            if (!segments.Any(s => s.Axis != a.Axis && Math.Abs(s.Position - along) < .01 && across >= s.Start && across <= s.End)) continue;
            var linked = State.Links.Any(l => l.FirstId == a.Id && l.SecondId == b.Id || l.FirstId == b.Id && l.SecondId == a.Id);
            result.Add(new(a.Id, b.Id, a.Axis == DividerAxis.Vertical ? across : along, a.Axis == DividerAxis.Vertical ? along : across, linked));
        }
        return result;
    }

    private bool LinksAreAdjacent(Dictionary<string, double> positions, double width, double height)
    {
        var boxes = Measure(positions, width, height);
        foreach (var link in State.Links)
        {
            var axis = _nodes[link.FirstId].Axis;
            var a = boxes[link.FirstId]; var b = boxes[link.SecondId];
            var gap = axis == DividerAxis.Vertical
                ? Math.Max(a.Y, b.Y) - Math.Min(a.Y + a.Height, b.Y + b.Height)
                : Math.Max(a.X, b.X) - Math.Min(a.X + a.Width, b.X + b.Width);
            if (Math.Abs(gap - Thickness) > .01) return false;
        }
        return true;
    }

    private bool IsValid(Dictionary<string, double> positions, double width, double height)
    {
        var boxes = Measure(positions, width, height);
        foreach (var (id, box) in boxes)
        {
            var min = _minimums[id];
            if (!double.IsFinite(box.Width) || !double.IsFinite(box.Height) || box.Width < min.Width - Epsilon || box.Height < min.Height - Epsilon) return false;
        }
        return State.Links.All(l => Math.Abs(positions[l.FirstId] - positions[l.SecondId]) < .01);
    }

    private Dictionary<string, LayoutBox> Measure(Dictionary<string, double> positions, double width, double height)
    {
        var boxes = new Dictionary<string, LayoutBox>();
        void Visit(DividerNode n, LayoutBox box)
        {
            boxes[n.Id] = box;
            if (!n.IsSplit) return;
            var (a, b) = Divide(box, n.Axis, positions[n.Id]); Visit(n.First!, a); Visit(n.Second!, b);
        }
        Visit(_root, new(0, 0, width, height)); return boxes;
    }

    private static (LayoutBox First, LayoutBox Second) Divide(LayoutBox b, DividerAxis axis, double p) => axis == DividerAxis.Vertical
        ? (new(b.X, b.Y, p - Thickness / 2 - b.X, b.Height), new(p + Thickness / 2, b.Y, b.X + b.Width - p - Thickness / 2, b.Height))
        : (new(b.X, b.Y, b.Width, p - Thickness / 2 - b.Y), new(b.X, p + Thickness / 2, b.Width, b.Y + b.Height - p - Thickness / 2));
}
