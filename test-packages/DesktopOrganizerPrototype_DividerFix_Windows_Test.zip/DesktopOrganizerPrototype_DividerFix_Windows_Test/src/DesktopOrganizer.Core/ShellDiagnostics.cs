using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Text.Json;
using Microsoft.Win32;

namespace DesktopOrganizer.Core;

public static class ShellDiagnostics
{
    private const string ExplorerAdvancedKey = @"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced";

    public static ShellProbeReport Capture()
    {
        var report = new ShellProbeReport
        {
            CapturedAtUtc = DateTimeOffset.UtcNow,
            OsVersion = Environment.OSVersion.VersionString,
            SessionId = Process.GetCurrentProcess().SessionId,
            UserSid = RecoveryRecordStore.CurrentUserSid()
        };
        ReadRegistry(report);
        ReadWindows(report);
        Assess(report);
        return report;
    }

    public static bool TryGetStableCandidateState(ShellProbeReport report, out string state, out string reason)
    {
        state = "Unknown";
        reason = "无法确认桌面图标状态。";
        if (!report.RegistrySignal.ReadSucceeded || !report.RegistrySignal.ValueExists)
        {
            reason = "HideIcons 候选值无法可靠读取。";
            return false;
        }

        bool expectedVisible;
        if (report.RegistrySignal.RawValue == "0") expectedVisible = true;
        else if (report.RegistrySignal.RawValue == "1") expectedVisible = false;
        else
        {
            reason = "HideIcons 候选值不是已知的 0 或 1。";
            return false;
        }

        var progman = report.Windows.FirstOrDefault(w => w.ClassName == "Progman");
        var listView = report.Windows.FirstOrDefault(w => w.ClassName == "SysListView32" && (progman is null || w.ProcessId == progman.ProcessId));
        if (listView is null)
        {
            reason = "未找到可关联到桌面 Shell 的 SysListView32 候选窗口。";
            return false;
        }

        if (listView.IsVisible != expectedVisible)
        {
            reason = $"候选信号冲突：HideIcons={report.RegistrySignal.RawValue}，SysListView32 可见性={listView.IsVisible}。严格停止。";
            return false;
        }

        state = expectedVisible ? "Visible" : "Hidden";
        reason = "两个候选信号一致；仍需由用户确认实际桌面画面。";
        return true;
    }

    public static string SaveDiagnosticReport(ShellProbeReport report)
    {
        AppDataPaths.EnsureDirectories();
        var path = Path.Combine(AppDataPaths.DiagnosticsDirectory, $"shell-{DateTime.UtcNow:yyyyMMdd-HHmmss}-{Guid.NewGuid():N}.json");
        var temp = path + ".tmp";
        try
        {
            using (var stream = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None, 4096, FileOptions.WriteThrough))
            {
                JsonSerializer.Serialize(stream, report, new JsonSerializerOptions { WriteIndented = true });
                stream.Flush(flushToDisk: true);
            }
            var check = JsonSerializer.Deserialize<ShellProbeReport>(File.ReadAllText(temp));
            if (check is null || check.CapturedAtUtc != report.CapturedAtUtc) throw new InvalidDataException("诊断报告校验失败。");
            File.Move(temp, path);
            return path;
        }
        finally
        {
            try { if (File.Exists(temp)) File.Delete(temp); } catch { }
        }
    }

    private static void ReadRegistry(ShellProbeReport report)
    {
        try
        {
            using var key = Registry.CurrentUser.OpenSubKey(ExplorerAdvancedKey, writable: false);
            if (key is null)
            {
                report.RegistrySignal = new RegistrySignal { ReadSucceeded = false, Error = "目标注册表键不存在或不可读取。" };
                return;
            }
            var value = key.GetValue("HideIcons", null, RegistryValueOptions.DoNotExpandEnvironmentNames);
            report.RegistrySignal = new RegistrySignal
            {
                ReadSucceeded = true,
                ValueExists = value is not null,
                ValueType = value is null ? null : key.GetValueKind("HideIcons").ToString(),
                RawValue = value?.ToString()
            };
        }
        catch (Exception ex)
        {
            report.RegistrySignal = new RegistrySignal { ReadSucceeded = false, Error = $"{ex.GetType().Name}: {ex.Message}" };
        }
    }

    private static void ReadWindows(ShellProbeReport report)
    {
        var found = new Dictionary<nint, ShellWindowSignal>();
        EnumWindows((top, _) =>
        {
            var className = GetClassNameSafe(top);
            if (className is "Progman" or "WorkerW")
            {
                Add(found, top, "top-level");
                EnumChildWindows(top, (child, _) =>
                {
                    var childClass = GetClassNameSafe(child);
                    if (childClass is "SHELLDLL_DefView" or "SysListView32") Add(found, child, "descendant");
                    return true;
                }, nint.Zero);
            }
            return true;
        }, nint.Zero);
        report.Windows = found.Values.OrderBy(w => w.ClassName, StringComparer.Ordinal).ThenBy(w => w.Handle, StringComparer.Ordinal).ToList();
    }

    private static void Assess(ShellProbeReport report)
    {
        if (TryGetStableCandidateState(report, out var state, out var reason))
        {
            report.CandidateState = state;
            report.SignalsConsistent = true;
            report.Assessment = reason;
        }
        else
        {
            report.CandidateState = "Unknown";
            report.SignalsConsistent = false;
            report.Assessment = reason;
        }
    }

    private static void Add(Dictionary<nint, ShellWindowSignal> found, nint hwnd, string relation)
    {
        var cls = GetClassNameSafe(hwnd);
        if (cls is not ("Progman" or "WorkerW" or "SHELLDLL_DefView" or "SysListView32")) return;
        _ = GetWindowThreadProcessId(hwnd, out var pid);
        found[hwnd] = new ShellWindowSignal
        {
            Handle = $"0x{hwnd.ToInt64():X}",
            ClassName = cls,
            IsVisible = IsWindowVisible(hwnd),
            ProcessId = pid,
            Relation = relation
        };
    }

    private static string GetClassNameSafe(nint hwnd)
    {
        var buffer = new StringBuilder(256);
        var length = GetClassName(hwnd, buffer, buffer.Capacity);
        return length > 0 ? buffer.ToString() : "";
    }

    private delegate bool EnumWindowsProc(nint hwnd, nint lParam);

    [DllImport("user32.dll", SetLastError = true)] private static extern bool EnumWindows(EnumWindowsProc callback, nint lParam);
    [DllImport("user32.dll", SetLastError = true)] private static extern bool EnumChildWindows(nint parent, EnumWindowsProc callback, nint lParam);
    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern int GetClassName(nint hwnd, StringBuilder className, int maxCount);
    [DllImport("user32.dll")] [return: MarshalAs(UnmanagedType.Bool)] private static extern bool IsWindowVisible(nint hwnd);
    [DllImport("user32.dll", SetLastError = true)] private static extern uint GetWindowThreadProcessId(nint hwnd, out uint processId);
}
