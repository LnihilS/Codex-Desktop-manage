using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace DesktopOrganizer.Core;

public sealed class LayoutDocument
{
    public int SchemaVersion { get; set; } = 1;
    public bool NeonEnabled { get; set; } = true;
    public string City { get; set; } = "成都";
    public string? BackgroundImagePath { get; set; }
    public string BackgroundTheme { get; set; } = "DarkGray";
    public string BackgroundColorHex { get; set; } = "#202630";
    public double PhotoOpacityPercent { get; set; } = 100;
    public Dictionary<string, double> RegionOpacities { get; set; } = new()
    {
        ["ApplicationsRegion"] = 65, ["TodoRegion"] = 65,
        ["ReferencesRegion"] = 65, ["ClockWeatherRegion"] = 65
    };
    // Legacy ratios retained for backward compatibility with V0.1 layouts.
    public double LeftColumnRatio { get; set; } = 2.15;
    public double RightColumnRatio { get; set; } = 1.05;
    public double TopRowRatio { get; set; } = 1.25;
    public double BottomRowRatio { get; set; } = 0.9;
    public double UpperLeftColumnRatio { get; set; }
    public double UpperRightColumnRatio { get; set; }
    public double LowerLeftColumnRatio { get; set; }
    public double LowerRightColumnRatio { get; set; }
    // Kept for backward compatibility with V0.1/V0.3 layouts; V0.3 uses per-category sizes.
    public double FontScale { get; set; } = 1.0;
    public double NeonLengthPercent { get; set; } = 100;
    public double NeonThickness { get; set; } = 8;
    // Position of the Applications title inside its region; older layouts default to (0, 0).
    public double ApplicationsTitleX { get; set; } = 0;
    public double ApplicationsTitleY { get; set; } = 0;
    public Dictionary<string, string> RegionTitles { get; set; } = new();
    public Dictionary<string, TitlePosition> TitlePositions { get; set; } = new();
    public Dictionary<string, double> FontSizes { get; set; } = new()
    {
        ["SectionTitle"] = 19, ["GeneralText"] = 12, ["AppName"] = 12,
        ["TodoText"] = 13, ["FileName"] = 12, ["FilePath"] = 10,
        ["Clock"] = 30, ["Date"] = 12, ["WeatherText"] = 12,
        ["ToolbarText"] = 12, ["StatusText"] = 11
    };
    public DividerLayoutState? Dividers { get; set; }
    public Dictionary<string, RegionSplitNode> RegionSplits { get; set; } = new();
    public List<ShortcutEntry> Shortcuts { get; set; } = [];
    public List<FileReferenceEntry> FileReferences { get; set; } = [];
    public List<TodoEntry> Todos { get; set; } = [];
}


public sealed class TitlePosition
{
    public double X { get; set; }
    public double Y { get; set; }
}

public sealed class RegionSplitNode
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    // A leaf has ContentKey set and no Orientation. A split has Orientation and two children.
    public string? ContentKey { get; set; }
    public string Title { get; set; } = "新分区";
    public string? Orientation { get; set; }
    public double Ratio { get; set; } = 0.5;
    public RegionSplitNode? First { get; set; }
    public RegionSplitNode? Second { get; set; }
}

public sealed class ShortcutEntry
{
    public string Name { get; set; } = "快捷方式";
    public string Path { get; set; } = "";
    public string Icon { get; set; } = "▣";
}

public sealed class FileReferenceEntry
{
    public string Name { get; set; } = "文件引用";
    public string Path { get; set; } = "";
}

public sealed class TodoEntry : INotifyPropertyChanged
{
    private string _text = "新任务";
    private bool _isDone;
    private bool _isEditing;

    public string Text
    {
        get => _text;
        set
        {
            if (_text == value) return;
            _text = value;
            OnPropertyChanged();
        }
    }

    public bool IsDone
    {
        get => _isDone;
        set
        {
            if (_isDone == value) return;
            _isDone = value;
            OnPropertyChanged();
        }
    }

    [JsonIgnore]
    public bool IsEditing
    {
        get => _isEditing;
        set
        {
            if (_isEditing == value) return;
            _isEditing = value;
            OnPropertyChanged();
        }
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnPropertyChanged([CallerMemberName] string? propertyName = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
}

public sealed class ShellProbeReport
{
    public DateTimeOffset CapturedAtUtc { get; set; } = DateTimeOffset.UtcNow;
    public string OsVersion { get; set; } = Environment.OSVersion.VersionString;
    public int SessionId { get; set; }
    public string UserSid { get; set; } = "unknown";
    public RegistrySignal RegistrySignal { get; set; } = new();
    public List<ShellWindowSignal> Windows { get; set; } = [];
    public string CandidateState { get; set; } = "Unknown";
    public bool SignalsConsistent { get; set; }
    public string Assessment { get; set; } = "未评估";
}

public sealed class RegistrySignal
{
    public bool ReadSucceeded { get; set; }
    public bool ValueExists { get; set; }
    public string? ValueType { get; set; }
    public string? RawValue { get; set; }
    public string? Error { get; set; }
}

public sealed class ShellWindowSignal
{
    public string Handle { get; set; } = "";
    public string ClassName { get; set; } = "";
    public bool IsVisible { get; set; }
    public uint ProcessId { get; set; }
    public string Relation { get; set; } = "top-level";
}

public sealed class RecoveryRecord
{
    public int SchemaVersion { get; set; } = 1;
    public string RunId { get; set; } = Guid.NewGuid().ToString("N");
    public string Status { get; set; } = "Prepared";
    public DateTimeOffset CreatedAtUtc { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset UpdatedAtUtc { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset? ResolvedAtUtc { get; set; }
    public string UserSid { get; set; } = "unknown";
    public int SessionId { get; set; }
    public int ProcessId { get; set; }
    public DateTimeOffset ProcessStartUtc { get; set; }
    public string ExecutablePath { get; set; } = "";
    public string OriginalIconStateCandidate { get; set; } = "Unknown";
    public bool UserConfirmedCandidateState { get; set; }
    public string? OriginalHideIconsRaw { get; set; }
    public bool? OriginalSysListViewVisible { get; set; }
    public bool? OriginalDefViewVisible { get; set; }
    public string? EmbedTargetHandle { get; set; }
    public bool NativeIconStateChanged { get; set; }
    public string LastMessage { get; set; } = "";
}
