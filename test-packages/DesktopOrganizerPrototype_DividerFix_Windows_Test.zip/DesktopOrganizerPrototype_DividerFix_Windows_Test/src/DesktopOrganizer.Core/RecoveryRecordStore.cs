using System.Security.Principal;
using System.Text.Json;

namespace DesktopOrganizer.Core;

public sealed class RecoveryRecordStore
{
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true, PropertyNameCaseInsensitive = true };

    public bool TryLoadActive(out RecoveryRecord? record, out string? error)
    {
        record = null;
        error = null;
        try
        {
            AppDataPaths.EnsureDirectories();
            if (!File.Exists(AppDataPaths.ActiveRecoveryPath)) return true;
            record = JsonSerializer.Deserialize<RecoveryRecord>(File.ReadAllText(AppDataPaths.ActiveRecoveryPath), JsonOptions);
            if (record is null || record.SchemaVersion != 1 || string.IsNullOrWhiteSpace(record.RunId))
            {
                record = null;
                error = "恢复记录为空或版本不受支持；为安全起见，不允许新的桌面接管。";
                return false;
            }
            return true;
        }
        catch (Exception ex)
        {
            error = $"恢复记录无法读取或校验：{ex.GetType().Name}。为安全起见，不允许新的桌面接管。";
            record = null;
            return false;
        }
    }

    public bool TryCreate(RecoveryRecord record, out string? error)
    {
        error = null;
        if (!TryLoadActive(out var existing, out error)) return false;
        if (existing is not null)
        {
            if (!string.Equals(existing.Status, "Resolved", StringComparison.Ordinal))
            {
                error = "发现尚未解决的恢复记录。请先使用独立恢复工具处理，不能开始新一轮接管。";
                return false;
            }
            if (!TryArchiveAndClear(existing, out error)) return false;
        }
        return TryWriteActive(record, out error);
    }

    public bool TryUpdate(RecoveryRecord record, out string? error)
    {
        error = null;
        if (!TryLoadActive(out var current, out error)) return false;
        if (current is null || !string.Equals(current.RunId, record.RunId, StringComparison.Ordinal))
        {
            error = "当前恢复记录不存在或运行标识不匹配，拒绝覆盖。";
            return false;
        }
        return TryWriteActive(record, out error);
    }

    public bool TryMarkResolved(RecoveryRecord record, string message, out string? error)
    {
        record.Status = "Resolved";
        record.UpdatedAtUtc = DateTimeOffset.UtcNow;
        record.ResolvedAtUtc = DateTimeOffset.UtcNow;
        record.LastMessage = message;
        if (!TryUpdate(record, out error)) return false;
        return TryArchiveAndClear(record, out error);
    }

    public bool TryFinalizeResolvedActive(out string? error)
    {
        error = null;
        if (!TryLoadActive(out var record, out error)) return false;
        if (record is null || !string.Equals(record.Status, "Resolved", StringComparison.Ordinal)) return true;
        return TryArchiveAndClear(record, out error);
    }

    public static string CurrentUserSid()
    {
        try { return WindowsIdentity.GetCurrent().User?.Value ?? "unknown"; }
        catch { return "unknown"; }
    }

    private static bool TryWriteActive(RecoveryRecord record, out string? error)
    {
        error = null;
        string? temp = null;
        try
        {
            AppDataPaths.EnsureDirectories();
            temp = AppDataPaths.ActiveRecoveryPath + ".tmp-" + Guid.NewGuid().ToString("N");
            record.UpdatedAtUtc = DateTimeOffset.UtcNow;
            using (var stream = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None, 4096, FileOptions.WriteThrough))
            {
                JsonSerializer.Serialize(stream, record, JsonOptions);
                stream.Flush(flushToDisk: true);
            }

            var verified = JsonSerializer.Deserialize<RecoveryRecord>(File.ReadAllText(temp), JsonOptions);
            if (verified is null || verified.RunId != record.RunId || verified.SchemaVersion != 1)
                throw new InvalidDataException("恢复记录写入后校验失败。");

            if (File.Exists(AppDataPaths.ActiveRecoveryPath))
            {
                // Preserve the currently active record before replacing it. If this copy fails, do not proceed.
                var old = JsonSerializer.Deserialize<RecoveryRecord>(File.ReadAllText(AppDataPaths.ActiveRecoveryPath), JsonOptions);
                if (old is null || old.SchemaVersion != 1)
                    throw new InvalidDataException("现有恢复记录无效；拒绝覆盖。");
                File.Copy(AppDataPaths.ActiveRecoveryPath, AppDataPaths.PreviousRecoveryPath, overwrite: true);
                var previousCheck = JsonSerializer.Deserialize<RecoveryRecord>(File.ReadAllText(AppDataPaths.PreviousRecoveryPath), JsonOptions);
                if (previousCheck is null || previousCheck.RunId != old.RunId)
                    throw new InvalidDataException("上一份恢复记录备份校验失败；拒绝覆盖。");
            }

            File.Move(temp, AppDataPaths.ActiveRecoveryPath, overwrite: true);
            temp = null;
            var activeCheck = JsonSerializer.Deserialize<RecoveryRecord>(File.ReadAllText(AppDataPaths.ActiveRecoveryPath), JsonOptions);
            if (activeCheck is null || activeCheck.RunId != record.RunId)
                throw new InvalidDataException("活动恢复记录最终校验失败。");
            return true;
        }
        catch (Exception ex)
        {
            error = $"恢复记录保存失败：{ex.GetType().Name}。禁止开始或继续桌面接管。";
            return false;
        }
        finally
        {
            if (temp is not null)
            {
                try { if (File.Exists(temp)) File.Delete(temp); } catch { /* best effort cleanup of app-owned temp file */ }
            }
        }
    }

    private static bool TryArchiveAndClear(RecoveryRecord record, out string? error)
    {
        error = null;
        try
        {
            AppDataPaths.EnsureDirectories();
            var archiveName = $"resolved-{DateTime.UtcNow:yyyyMMdd-HHmmss}-{record.RunId}.json";
            var archivePath = Path.Combine(AppDataPaths.RecoveryHistoryDirectory, archiveName);
            var temp = archivePath + ".tmp-" + Guid.NewGuid().ToString("N");
            using (var stream = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None, 4096, FileOptions.WriteThrough))
            {
                JsonSerializer.Serialize(stream, record, JsonOptions);
                stream.Flush(flushToDisk: true);
            }
            var verified = JsonSerializer.Deserialize<RecoveryRecord>(File.ReadAllText(temp), JsonOptions);
            if (verified is null || verified.RunId != record.RunId || verified.Status != "Resolved")
                throw new InvalidDataException("已解决记录归档校验失败。");
            if (!File.Exists(archivePath)) File.Move(temp, archivePath);
            else File.Delete(temp);

            // Delete active only after a verified archive exists and still refers to this run.
            if (File.Exists(AppDataPaths.ActiveRecoveryPath))
            {
                var active = JsonSerializer.Deserialize<RecoveryRecord>(File.ReadAllText(AppDataPaths.ActiveRecoveryPath), JsonOptions);
                if (active is not null && active.RunId == record.RunId && active.Status == "Resolved")
                    File.Delete(AppDataPaths.ActiveRecoveryPath);
            }
            CleanupHistory();
            return true;
        }
        catch (Exception ex)
        {
            error = $"记录已尝试标记为已解决，但归档或清理未完成：{ex.GetType().Name}。记录将保留供后续处理。";
            return false;
        }
    }

    private static void CleanupHistory()
    {
        try
        {
            var files = new DirectoryInfo(AppDataPaths.RecoveryHistoryDirectory)
                .GetFiles("resolved-*.json")
                .OrderByDescending(f => f.LastWriteTimeUtc)
                .ToList();
            var keepCount = 20;
            var minimumAge = TimeSpan.FromDays(30);
            for (var i = keepCount; i < files.Count; i++)
            {
                if (DateTime.UtcNow - files[i].LastWriteTimeUtc >= minimumAge)
                    files[i].Delete();
            }
        }
        catch { /* history cleanup must never invalidate a recovery record */ }
    }
}
