using System.IO;
using System.Diagnostics;
using System.Security.Principal;
using System.Text;
using System.Windows;
using DesktopOrganizer.Core;

namespace DesktopOrganizer.Recovery;

public partial class RecoveryWindow : Window
{
    private readonly RecoveryRecordStore _store = new();
    private RecoveryRecord? _record;
    private string? _loadError;

    public RecoveryWindow()
    {
        InitializeComponent();
        RefreshRecord();
    }

    private void RefreshButton_Click(object sender, RoutedEventArgs e) => RefreshRecord();

    private void RefreshRecord()
    {
        if (!_store.TryLoadActive(out _record, out _loadError))
        {
            RecordStatusText.Text = "恢复记录无法可靠读取：禁止自动恢复";
            RecordDetailsText.Text = _loadError + "\n\n请保留恢复记录文件，必要时导出诊断信息。不要手动删除活动记录。";
            return;
        }

        if (_record is null)
        {
            RecordStatusText.Text = "没有未解决的活动恢复记录";
            RecordDetailsText.Text = "当前没有活动恢复记录。此原型不会修改原生桌面图标。\n\n记录目录：\n" + AppDataPaths.RecoveryDirectory;
            return;
        }

        RecordStatusText.Text = "发现恢复记录：" + _record.Status;
        var sb = new StringBuilder();
        sb.AppendLine($"运行标识：{_record.RunId}");
        sb.AppendLine($"状态：{_record.Status}");
        sb.AppendLine($"创建时间（UTC）：{_record.CreatedAtUtc:O}");
        sb.AppendLine($"用户 SID：{_record.UserSid}");
        sb.AppendLine($"会话 ID：{_record.SessionId}");
        sb.AppendLine($"进程 ID：{_record.ProcessId}");
        sb.AppendLine($"程序路径：{_record.ExecutablePath}");
        sb.AppendLine($"图标状态候选值：{_record.OriginalIconStateCandidate}");
        sb.AppendLine($"本原型是否修改原生图标：{_record.NativeIconStateChanged}");
        sb.AppendLine($"最后信息：{_record.LastMessage}");
        sb.AppendLine();
        sb.AppendLine("安全原则：若记录归属或当前状态无法确认，不自动猜测、不覆盖、不删除活动记录。");
        RecordDetailsText.Text = sb.ToString();
    }

    private void StopHostButton_Click(object sender, RoutedEventArgs e)
    {
        if (_record is null)
        {
            MessageBox.Show(this, _loadError ?? "没有活动恢复记录。", "无需停止", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        var currentSid = RecoveryRecordStore.CurrentUserSid();
        if (string.IsNullOrWhiteSpace(currentSid) || currentSid == "unknown" || !string.Equals(_record.UserSid, currentSid, StringComparison.Ordinal))
        {
            MessageBox.Show(this, "记录不属于当前用户，拒绝操作其他用户的进程或桌面。", "用户归属不匹配", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        Process? host = null;
        try { host = Process.GetProcessById(_record.ProcessId); }
        catch (ArgumentException) { /* process is no longer running */ }
        catch (InvalidOperationException) { /* process is no longer running */ }

        if (host is null)
        {
            if (!_record.NativeIconStateChanged)
            {
                if (_store.TryMarkResolved(_record, "恢复工具确认本原型宿主已退出；本原型未修改原生图标状态。", out var archiveError))
                {
                    MessageBox.Show(this, "主程序已不在运行，且记录确认本原型未修改原生图标。记录已归档。", "恢复核验完成", MessageBoxButton.OK, MessageBoxImage.Information);
                    RefreshRecord();
                }
                else
                {
                    MessageBox.Show(this, archiveError ?? "记录归档未完成；请保留记录。", "归档未完成", MessageBoxButton.OK, MessageBoxImage.Warning);
                    RefreshRecord();
                }
            }
            else
            {
                MessageBox.Show(this, "主程序已不在运行，但记录表明它可能修改过原生图标。恢复工具不会猜测原始状态；请保留记录并使用手动修复流程。", "需要手动恢复", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            return;
        }

        try
        {
            using (host)
            {
                var actualPath = host.MainModule?.FileName;
                var actualStart = new DateTimeOffset(host.StartTime.ToUniversalTime());
                var samePath = !string.IsNullOrWhiteSpace(actualPath) && string.Equals(Path.GetFullPath(actualPath), Path.GetFullPath(_record.ExecutablePath), StringComparison.OrdinalIgnoreCase);
                var sameStart = Math.Abs((actualStart - _record.ProcessStartUtc).TotalSeconds) <= 3;
                var sameSession = host.SessionId == _record.SessionId;
                if (!samePath || !sameStart || !sameSession || host.ProcessName != "DesktopOrganizer.App")
                {
                    MessageBox.Show(this, "进程路径、启动时间、会话或名称与恢复记录不完全匹配。为避免结束错误进程，操作已取消。", "进程身份核验失败", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                var confirm = MessageBox.Show(this,
                    $"即将结束已核验的桌面整理原型进程 PID {host.Id}。\n\n这会关闭本原型窗口，但不会修改原生桌面图标。是否继续？",
                    "确认停止原型进程", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                if (confirm != MessageBoxResult.Yes) return;
                host.Kill(entireProcessTree: false);
                if (!host.WaitForExit(5000))
                {
                    MessageBox.Show(this, "等待进程退出超时。恢复记录已保留，请勿删除。", "停止未能确认", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
            }

            if (!_record.NativeIconStateChanged)
            {
                if (_store.TryMarkResolved(_record, "恢复工具结束了身份核验通过的原型进程；本原型未修改原生图标状态。", out var archiveError))
                    MessageBox.Show(this, "原型进程已结束，活动恢复记录已核验并归档。", "恢复完成", MessageBoxButton.OK, MessageBoxImage.Information);
                else
                    MessageBox.Show(this, "原型进程已结束，但记录归档未完成。请保留恢复记录。\n" + archiveError, "记录待处理", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            else
            {
                MessageBox.Show(this, "原型进程已结束，但记录表明它可能修改过原生图标。为避免猜测，恢复记录仍然保留，请继续手动恢复。", "需要手动恢复", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            RefreshRecord();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "无法安全停止目标进程。恢复记录已保留。\n" + ex.Message, "恢复操作失败", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void SafeModeButton_Click(object sender, RoutedEventArgs e)
    {
        var appExe = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "App", "DesktopOrganizer.App.exe"));
        if (!File.Exists(appExe))
        {
            MessageBox.Show(this, "未找到主程序。请先运行项目根目录的 build.ps1。\n\n预期路径：\n" + appExe, "主程序未发布", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        try
        {
            Process.Start(new ProcessStartInfo(appExe, "--safe-mode") { UseShellExecute = true });
            FooterText.Text = "已请求以安全模式启动主程序；该模式不会启动桌面嵌入。";
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "安全启动失败", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    private void OpenFolderButton_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            Directory.CreateDirectory(AppDataPaths.RecoveryDirectory);
            Process.Start(new ProcessStartInfo("explorer.exe", $"\"{AppDataPaths.RecoveryDirectory}\"") { UseShellExecute = true });
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "无法打开记录目录", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }
}
