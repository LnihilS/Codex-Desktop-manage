using System.Windows;

namespace DesktopOrganizer.Recovery;

public partial class App : Application
{
}
