using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using System.Threading;
using System.Net.Http;
using System.Text.Json;
using System.Globalization;
using DesktopOrganizer.Core;
using Microsoft.Win32;

namespace DesktopOrganizer.App;

public partial class MainWindow : Window
{
    private LayoutDocument? _layout;
    private readonly RecoveryRecordStore _recoveryStore = new();
    private readonly DesktopEmbedController _embedController = new();
    private readonly DispatcherTimer _clockTimer = new() { Interval = TimeSpan.FromSeconds(1) };
    private ObservableCollection<ShortcutEntry> _shortcuts = [];
    private ObservableCollection<FileReferenceEntry> _fileReferences = [];
    private ObservableCollection<TodoEntry> _todos = [];
    private RecoveryRecord? _activeRecord;
    private bool _isEditing;
    private bool _isLoadingLayout = true;
    private bool _startupRecoveryBlock;
    private bool _layoutLoadFailed;
    private Mutex? _embedMutex;
    private bool _ownsEmbedMutex;
    private bool _fontDialogUpdating;
    private Point _shortcutDragStartPoint;
    private ShortcutEntry? _shortcutDragCandidate;
    private DateTime _lastShortcutDragUtc = DateTime.MinValue;
    private bool _weatherLoading;
    private static readonly HttpClient WeatherHttpClient = new() { Timeout = TimeSpan.FromSeconds(10) };
    private static readonly string DefaultMsnWeatherUrl = "https://www.msn.cn/zh-cn/weather/forecast/in-%E5%8F%8C%E6%B5%81%E5%8C%BA?loc=eyJsIjoi5Y%2BM5rWB5Yy6IiwiYyI6IuS4reWNjuS6uuawkeWFseWSjOWbvSIsImkiOiJDTiIsIngiOiIxMDMuOTk3MiIsInkiOiIzMC41NjQ5In0%3D&weadegreetype=C&ocid=ansmsnweather";
    private TextBlock? _draggingSectionTitle;
    private Canvas? _draggingSectionTitleCanvas;
    private Point _sectionTitleDragOffset;
    private readonly Dictionary<string, TextBlock> _titleTextBlocks = new();
    private readonly Dictionary<string, RegionSplitNode> _regionRoots = new();
    private readonly Dictionary<string, Border> _regionContentPanels = new();
    private readonly Dictionary<string, Grid> _regionOuterGrids = new();
    private readonly Dictionary<string, FrameworkElement> _regionVisualRoots = new();
    private readonly Dictionary<FrameworkElement, (string RootKey, RegionSplitNode Node)> _regionLeafMap = new();
    private readonly Dictionary<FrameworkElement, string> _regionElementRootKeys = new();
    private readonly HashSet<GridSplitter> _dynamicSplitters = new();
    private readonly Dictionary<GridSplitter, string> _dynamicSplitterRootKeys = new();

    public MainWindow()
    {
        InitializeComponent();
        Loaded += async (_, _) => await RefreshWeatherAsync();
        RootGrid.AddHandler(FrameworkElement.LoadedEvent, new RoutedEventHandler(AnyElement_Loaded), true);
        _layout = LayoutStore.Load(out var layoutWarning);
        _layoutLoadFailed = !string.IsNullOrWhiteSpace(layoutWarning);
        _layout.RegionTitles ??= new Dictionary<string, string>();
        _layout.TitlePositions ??= new Dictionary<string, TitlePosition>();

        _shortcuts = new ObservableCollection<ShortcutEntry>(_layout.Shortcuts);
        _fileReferences = new ObservableCollection<FileReferenceEntry>(_layout.FileReferences);
        _todos = new ObservableCollection<TodoEntry>(_layout.Todos);
        ShortcutItems.ItemsSource = _shortcuts;
        FileReferenceItems.ItemsSource = _fileReferences;
        TodoItems.ItemsSource = _todos;

        _shortcuts.CollectionChanged += Collections_Changed;
        _fileReferences.CollectionChanged += Collections_Changed;
        _todos.CollectionChanged += Todos_CollectionChanged;
        foreach (var todo in _todos) todo.PropertyChanged += Todo_PropertyChanged;

        CityTextBox.Text = string.IsNullOrWhiteSpace(_layout.City) || _layout.City == "成都" ? "双流区" : _layout.City;
        _layout.City = CityTextBox.Text;
        RegisterSectionTitle(ApplicationsTitle);
        RegisterSectionTitle(TodoTitle);
        RegisterSectionTitle(ReferencesTitle);
        RegisterSectionTitle(ClockWeatherTitle);
        _layout.FontSizes ??= new Dictionary<string, double>();
        EnsureFontDefaults(_layout.FontSizes);
        _layout.RegionOpacities ??= new Dictionary<string, double>();
        EnsureRegionOpacityDefaults(_layout.RegionOpacities);
        _layout.BackgroundTheme ??= "DarkGray";
        _layout.BackgroundColorHex = NormalizeHexColor(_layout.BackgroundColorHex, "#202630");
        _layout.PhotoOpacityPercent = Math.Clamp(_layout.PhotoOpacityPercent, 0, 100);
        _layout.NeonLengthPercent = Math.Clamp(_layout.NeonLengthPercent, 20, 100);
        _layout.NeonThickness = Math.Clamp(_layout.NeonThickness, 2, 20);
        RootGrid.SizeChanged += RootGrid_SizeChanged;
        if (_layout.UpperLeftColumnRatio <= 0.05 || _layout.UpperRightColumnRatio <= 0.05)
        {
            _layout.UpperLeftColumnRatio = _layout.LeftColumnRatio;
            _layout.UpperRightColumnRatio = _layout.RightColumnRatio;
        }
        if (_layout.LowerLeftColumnRatio <= 0.05 || _layout.LowerRightColumnRatio <= 0.05)
        {
            _layout.LowerLeftColumnRatio = _layout.LeftColumnRatio;
            _layout.LowerRightColumnRatio = _layout.RightColumnRatio;
        }
        UpperRegionGrid.ColumnDefinitions[0].Width = new GridLength(_layout.UpperLeftColumnRatio, GridUnitType.Star);
        UpperRegionGrid.ColumnDefinitions[2].Width = new GridLength(_layout.UpperRightColumnRatio, GridUnitType.Star);
        LowerRegionGrid.ColumnDefinitions[0].Width = new GridLength(_layout.LowerLeftColumnRatio, GridUnitType.Star);
        LowerRegionGrid.ColumnDefinitions[2].Width = new GridLength(_layout.LowerRightColumnRatio, GridUnitType.Star);
        DesktopGrid.RowDefinitions[0].Height = new GridLength(Math.Max(0.2, _layout.TopRowRatio), GridUnitType.Star);
        DesktopGrid.RowDefinitions[2].Height = new GridLength(Math.Max(0.2, _layout.BottomRowRatio), GridUnitType.Star);
        InitializeRegionLayouts();
        InitializeDividerController();
        ApplyIndividualFontSizes();
        ApplyNeonDimensions();
        NeonBar.Visibility = _layout.NeonEnabled ? Visibility.Visible : Visibility.Collapsed;
        ApplyToolbarSpacing();
        NeonToggleButton.Content = _layout.NeonEnabled ? "关闭霓虹" : "开启霓虹";
        ApplyBackground(_layout.BackgroundImagePath, showMissingWarning: true);

        _clockTimer.Tick += (_, _) => UpdateClock();
        _clockTimer.Start();
        UpdateClock();
        SetEditMode(false);

        if (!string.IsNullOrWhiteSpace(layoutWarning))
            SetStatus(layoutWarning);

        CheckStartupRecoveryState();
        if (App.IsSafeMode)
        {
            _startupRecoveryBlock = true;
            SetStatus("安全模式：桌面嵌入实验已禁用；原生桌面图标未被本原型修改。");
            ModeText.Text = "安全模式";
        }
        _isLoadingLayout = false;
        UpdateRecoveryStateText();
    }

    private void CheckStartupRecoveryState()
    {
        if (!_recoveryStore.TryFinalizeResolvedActive(out var finalizeError))
        {
            _startupRecoveryBlock = true;
            SetStatus(finalizeError ?? "无法处理上次恢复记录；已禁止新的桌面接管。");
            return;
        }

        if (!_recoveryStore.TryLoadActive(out var record, out var loadError))
        {
            _startupRecoveryBlock = true;
            SetStatus(loadError ?? "恢复记录无法确认；已禁止新的桌面接管。");
            return;
        }

        if (record is not null && !string.Equals(record.Status, "Resolved", StringComparison.Ordinal))
        {
            _startupRecoveryBlock = true;
            _activeRecord = record;
            SetStatus("发现尚未解决的遗留恢复记录。请先打开独立恢复工具；本次不会自动嵌入或修改图标。");
        }
    }

    private void SetEditMode(bool enabled)
    {
        if (!enabled) FinishDividerDrag(cancel: false);
        _isEditing = enabled;
        ModeText.Text = enabled ? "编辑模式" : (App.IsSafeMode ? "安全模式" : "日常模式");
        EditModeButton.Content = enabled ? "完成编辑" : "进入编辑";
        AddShortcutButton.IsEnabled = enabled;
        AddFileButton.IsEnabled = enabled;
        VerticalSplitterTop.IsEnabled = enabled;
        VerticalSplitterBottom.IsEnabled = enabled;
        HorizontalSplitterMain.IsEnabled = enabled;
        foreach (var splitter in _dynamicSplitters) splitter.IsEnabled = enabled;
        RefreshDividerJunctions();
        ApplicationsTitle.Cursor = enabled ? Cursors.SizeAll : Cursors.Arrow;
        ApplicationsTitle.ToolTip = enabled ? "编辑模式：拖动此标题可调整位置" : "";
        SetStatus(_dividerError ?? (enabled ? "编辑模式：拖动分割线；右键交点亮斑可合并或取消合并。布局会自动保存。" : "日常模式：分割线和标题已锁定，避免误触。原生桌面图标未被修改."));
    }

    private void RegisterSectionTitle(TextBlock title)
    {
        if (string.IsNullOrWhiteSpace(title.Uid)) return;
        _titleTextBlocks[title.Uid] = title;

        if (_layout is not null)
        {
            if (title.Uid.StartsWith("custom:", StringComparison.Ordinal))
            {
                var node = FindRegionNodeById(title.Uid.Substring("custom:".Length));
                if (node is not null && !string.IsNullOrWhiteSpace(node.Title))
                    title.Text = node.Title;
            }
            else if (_layout.RegionTitles.TryGetValue(title.Uid, out var savedTitle) && !string.IsNullOrWhiteSpace(savedTitle))
            {
                title.Text = savedTitle;
            }

            if (_layout.TitlePositions.TryGetValue(title.Uid, out var position))
            {
                Canvas.SetLeft(title, position.X);
                Canvas.SetTop(title, position.Y);
            }
            else if (title.Uid == "ApplicationsRegion")
            {
                Canvas.SetLeft(title, _layout.ApplicationsTitleX);
                Canvas.SetTop(title, _layout.ApplicationsTitleY);
            }
        }
    }

    private RegionSplitNode? FindRegionNodeById(string id)
    {
        foreach (var root in _regionRoots.Values)
        {
            var found = FindRegionNodeById(root, id);
            if (found is not null) return found;
        }
        return null;
    }

    private static RegionSplitNode? FindRegionNodeById(RegionSplitNode node, string id)
    {
        if (node.Id == id) return node;
        if (node.First is not null)
        {
            var found = FindRegionNodeById(node.First, id);
            if (found is not null) return found;
        }
        if (node.Second is not null)
            return FindRegionNodeById(node.Second, id);
        return null;
    }

    private void SectionTitle_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (!_isEditing || sender is not TextBlock title) return;

        if (e.ClickCount >= 2)
        {
            EditSectionTitle(title);
            e.Handled = true;
            return;
        }

        if (VisualTreeHelper.GetParent(title) is not Canvas canvas) return;
        _draggingSectionTitle = title;
        _draggingSectionTitleCanvas = canvas;
        var left = Canvas.GetLeft(title);
        var top = Canvas.GetTop(title);
        if (double.IsNaN(left)) left = 0;
        if (double.IsNaN(top)) top = 0;
        var pointer = e.GetPosition(canvas);
        _sectionTitleDragOffset = new Point(pointer.X - left, pointer.Y - top);
        title.CaptureMouse();
        e.Handled = true;
    }

    private void SectionTitle_MouseMove(object sender, MouseEventArgs e)
    {
        if (_draggingSectionTitle is null || _draggingSectionTitleCanvas is null ||
            e.LeftButton != MouseButtonState.Pressed) return;

        var title = _draggingSectionTitle;
        var canvas = _draggingSectionTitleCanvas;
        var point = e.GetPosition(canvas);
        var x = point.X - _sectionTitleDragOffset.X;
        var y = point.Y - _sectionTitleDragOffset.Y;

        // A small negative top offset lets a title move upward even when it starts at the top edge.
        x = Math.Clamp(x, -8, Math.Max(-8, canvas.ActualWidth - title.ActualWidth));
        y = Math.Clamp(y, -24, Math.Max(-24, canvas.ActualHeight - title.ActualHeight));
        Canvas.SetLeft(title, x);
        Canvas.SetTop(title, y);
        e.Handled = true;
    }

    private void SectionTitle_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        if (_draggingSectionTitle is null) return;
        var title = _draggingSectionTitle;
        title.ReleaseMouseCapture();
        _draggingSectionTitle = null;
        _draggingSectionTitleCanvas = null;

        if (_layout is not null && !string.IsNullOrWhiteSpace(title.Uid))
        {
            var x = Canvas.GetLeft(title);
            var y = Canvas.GetTop(title);
            if (double.IsNaN(x) || double.IsInfinity(x)) x = 0;
            if (double.IsNaN(y) || double.IsInfinity(y)) y = 0;
            _layout.TitlePositions[title.Uid] = new TitlePosition { X = x, Y = y };
            if (title.Uid == "ApplicationsRegion")
            {
                _layout.ApplicationsTitleX = x;
                _layout.ApplicationsTitleY = y;
            }
            SaveLayout();
            SetStatus($"标题“{title.Text}”的位置已保存。");
        }
        e.Handled = true;
    }

    private void EditSectionTitle(TextBlock title)
    {
        if (_layout is null || string.IsNullOrWhiteSpace(title.Uid)) return;
        var dialog = new Window
        {
            Title = "编辑分区标题",
            Owner = this,
            Width = 360,
            Height = 170,
            ResizeMode = ResizeMode.NoResize,
            WindowStartupLocation = WindowStartupLocation.CenterOwner,
            Background = new SolidColorBrush(Color.FromRgb(16, 19, 24)),
            Foreground = new SolidColorBrush(Color.FromRgb(238, 242, 247))
        };
        var panel = new StackPanel { Margin = new Thickness(16) };
        panel.Children.Add(new TextBlock { Text = "输入新的标题文字", Margin = new Thickness(0, 0, 0, 7) });
        var input = new TextBox
        {
            Text = title.Text,
            Background = new SolidColorBrush(Color.FromRgb(31, 38, 48)),
            Foreground = new SolidColorBrush(Color.FromRgb(238, 242, 247)),
            BorderBrush = new SolidColorBrush(Color.FromRgb(65, 78, 94)),
            Padding = new Thickness(7),
            Margin = new Thickness(0, 0, 0, 12)
        };
        input.SelectAll();
        panel.Children.Add(input);
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
        var cancel = new Button { Content = "取消", Style = (Style)FindResource("ToolbarButton"), MinWidth = 72, Margin = new Thickness(0, 0, 8, 0) };
        cancel.Click += (_, _) => dialog.DialogResult = false;
        var save = new Button { Content = "保存", Style = (Style)FindResource("ToolbarButton"), MinWidth = 72 };
        save.Click += (_, _) => dialog.DialogResult = true;
        buttons.Children.Add(cancel);
        buttons.Children.Add(save);
        panel.Children.Add(buttons);
        dialog.Content = panel;
        dialog.Loaded += (_, _) => { input.Focus(); input.SelectAll(); };
        if (dialog.ShowDialog() != true) return;

        var newTitle = input.Text.Trim();
        if (string.IsNullOrWhiteSpace(newTitle)) return;
        title.Text = newTitle;
        if (title.Uid.StartsWith("custom:", StringComparison.Ordinal))
        {
            var node = FindRegionNodeById(title.Uid.Substring("custom:".Length));
            if (node is not null) node.Title = newTitle;
        }
        else
        {
            _layout.RegionTitles[title.Uid] = newTitle;
        }
        SaveLayout();
        SetStatus("分区标题已更新。");
    }

    private void InitializeRegionLayouts()
    {
        _regionContentPanels["ApplicationsRegion"] = ApplicationsRegion;
        _regionContentPanels["TodoRegion"] = TodoRegion;
        _regionContentPanels["ReferencesRegion"] = ReferencesRegion;
        _regionContentPanels["ClockWeatherRegion"] = ClockWeatherRegion;
        _regionOuterGrids["ApplicationsRegion"] = UpperRegionGrid;
        _regionOuterGrids["TodoRegion"] = UpperRegionGrid;
        _regionOuterGrids["ReferencesRegion"] = LowerRegionGrid;
        _regionOuterGrids["ClockWeatherRegion"] = LowerRegionGrid;

        _layout!.RegionSplits ??= new Dictionary<string, RegionSplitNode>();
        foreach (var key in _regionContentPanels.Keys.ToList())
        {
            var root = _layout.RegionSplits.TryGetValue(key, out var saved) && IsValidRegionTree(saved, key) && CountContentLeaves(saved, key) == 1
                ? saved
                : new RegionSplitNode { ContentKey = key };
            _regionRoots[key] = root;
            var panel = _regionContentPanels[key];
            var outer = _regionOuterGrids[key];
            var row = Grid.GetRow(panel);
            var column = Grid.GetColumn(panel);
            var rowSpan = Grid.GetRowSpan(panel);
            var columnSpan = Grid.GetColumnSpan(panel);
            var index = outer.Children.IndexOf(panel);
            outer.Children.Remove(panel);
            var visual = BuildRegionVisual(root, key, panel);
            Grid.SetRow(visual, row);
            Grid.SetColumn(visual, column);
            Grid.SetRowSpan(visual, rowSpan);
            Grid.SetColumnSpan(visual, columnSpan);
            outer.Children.Insert(Math.Clamp(index, 0, outer.Children.Count), visual);
            _regionVisualRoots[key] = visual;
        }
    }

    private static bool IsValidRegionTree(RegionSplitNode? node, string regionKey)
    {
        if (node is null) return false;
        if (string.IsNullOrWhiteSpace(node.Orientation))
            return node.First is null && node.Second is null && (node.ContentKey == regionKey || node.ContentKey == "__empty__");
        if (node.Orientation is not ("Vertical" or "Horizontal") || node.First is null || node.Second is null || !double.IsFinite(node.Ratio) || node.Ratio <= 0 || node.Ratio >= 1)
            return false;
        return IsValidRegionTree(node.First, regionKey) && IsValidRegionTree(node.Second, regionKey);
    }

    private static int CountContentLeaves(RegionSplitNode? node, string regionKey)
    {
        if (node is null) return 0;
        if (string.IsNullOrWhiteSpace(node.Orientation)) return node.ContentKey == regionKey ? 1 : 0;
        return CountContentLeaves(node.First, regionKey) + CountContentLeaves(node.Second, regionKey);
    }

    private FrameworkElement BuildRegionVisual(RegionSplitNode node, string rootKey, Border originalPanel)
    {
        if (string.IsNullOrWhiteSpace(node.Orientation))
        {
            Border leaf;
            if (node.ContentKey == rootKey)
            {
                leaf = originalPanel;
            }
            else
            {
                var titleCanvas = new Canvas { ClipToBounds = false };
                var dynamicTitle = new TextBlock
                {
                    Uid = "custom:" + node.Id,
                    Text = string.IsNullOrWhiteSpace(node.Title) ? "新分区" : node.Title,
                    Tag = "SectionTitle",
                    FontSize = 17,
                    FontWeight = FontWeights.SemiBold,
                    Foreground = new SolidColorBrush(Color.FromRgb(185, 198, 214))
                };
                dynamicTitle.PreviewMouseLeftButtonDown += SectionTitle_MouseLeftButtonDown;
                dynamicTitle.PreviewMouseMove += SectionTitle_MouseMove;
                dynamicTitle.PreviewMouseLeftButtonUp += SectionTitle_MouseLeftButtonUp;
                Canvas.SetLeft(dynamicTitle, 0);
                Canvas.SetTop(dynamicTitle, 0);
                titleCanvas.Children.Add(dynamicTitle);
                RegisterSectionTitle(dynamicTitle);
                // Keep new partitions visually clean: the title remains, while split actions stay in the context menu.
                var leafContent = new Grid();
                leafContent.Children.Add(titleCanvas);
                leaf = new Border
                {
                    Background = new SolidColorBrush(GetRegionPanelColor(rootKey)),
                    BorderBrush = new SolidColorBrush(Color.FromRgb(57, 66, 79)),
                    BorderThickness = new Thickness(1),
                    CornerRadius = new CornerRadius(5),
                    Padding = new Thickness(14),
                    Child = leafContent
                };
            }
            Grid.SetRow(leaf, 0);
            Grid.SetColumn(leaf, 0);
            Grid.SetRowSpan(leaf, 1);
            Grid.SetColumnSpan(leaf, 1);
            _regionLeafMap[leaf] = (rootKey, node);
            _regionElementRootKeys[leaf] = rootKey;
            AttachRegionContextMenu(leaf);
            return leaf;
        }

        var host = new Grid { Background = Brushes.Transparent, Tag = node, ClipToBounds = true };
        _regionElementRootKeys[host] = rootKey;
        if (node.Orientation == "Vertical")
        {
            host.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(Math.Clamp(node.Ratio, 0.000001, 0.999999), GridUnitType.Star), MinWidth = 70 });
            host.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(5) });
            host.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1 - Math.Clamp(node.Ratio, 0.000001, 0.999999), GridUnitType.Star), MinWidth = 70 });
            var first = BuildRegionVisual(node.First!, rootKey, originalPanel);
            var splitter = CreateDynamicSplitter(rootKey, node, horizontalLine: false);
            RegisterDivider(DividerId(node), host, splitter, DividerAxis.Vertical);
            var second = BuildRegionVisual(node.Second!, rootKey, originalPanel);
            Grid.SetColumn(first, 0); Grid.SetColumn(splitter, 1); Grid.SetColumn(second, 2);
            host.Children.Add(first); host.Children.Add(splitter); host.Children.Add(second);
        }
        else
        {
            host.RowDefinitions.Add(new RowDefinition { Height = new GridLength(Math.Clamp(node.Ratio, 0.000001, 0.999999), GridUnitType.Star), MinHeight = 55 });
            host.RowDefinitions.Add(new RowDefinition { Height = new GridLength(5) });
            host.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1 - Math.Clamp(node.Ratio, 0.000001, 0.999999), GridUnitType.Star), MinHeight = 55 });
            var first = BuildRegionVisual(node.First!, rootKey, originalPanel);
            var splitter = CreateDynamicSplitter(rootKey, node, horizontalLine: true);
            RegisterDivider(DividerId(node), host, splitter, DividerAxis.Horizontal);
            var second = BuildRegionVisual(node.Second!, rootKey, originalPanel);
            Grid.SetRow(first, 0); Grid.SetRow(splitter, 1); Grid.SetRow(second, 2);
            host.Children.Add(first); host.Children.Add(splitter); host.Children.Add(second);
        }
        return host;
    }

    private GridSplitter CreateDynamicSplitter(string rootKey, RegionSplitNode node, bool horizontalLine)
    {
        var splitter = new GridSplitter
        {
            Width = horizontalLine ? double.NaN : 5,
            Height = horizontalLine ? 5 : double.NaN,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            VerticalAlignment = VerticalAlignment.Stretch,
            ResizeDirection = horizontalLine ? GridResizeDirection.Rows : GridResizeDirection.Columns,
            ResizeBehavior = GridResizeBehavior.PreviousAndNext,
            ShowsPreview = true,
            Cursor = horizontalLine ? Cursors.SizeNS : Cursors.SizeWE,
            IsEnabled = _isEditing,
            Background = new SolidColorBrush(Color.FromRgb(72, 84, 99)),
            Opacity = 0.9
        };
        var menu = new ContextMenu();
        var delete = new MenuItem { Header = "删除此分割线并合并分区" };
        delete.Click += DeleteSplit_Click;
        menu.Items.Add(delete);
        splitter.ContextMenu = menu;
        _dynamicSplitters.Add(splitter);
        _dynamicSplitterRootKeys[splitter] = rootKey;
        return splitter;
    }

    private void AttachRegionContextMenu(Border region)
    {
        var menu = new ContextMenu();
        var horizontal = new MenuItem { Header = "在此分区新增横向分割线", Tag = "Horizontal" };
        horizontal.Click += SplitRegion_Click;
        var vertical = new MenuItem { Header = "在此分区新增纵向分割线", Tag = "Vertical" };
        vertical.Click += SplitRegion_Click;
        menu.Items.Add(horizontal);
        menu.Items.Add(vertical);
        region.ContextMenu = menu;
    }

    private void SplitRegion_Click(object sender, RoutedEventArgs e)
    {
        if (!_isEditing)
        {
            SetStatus("请先进入编辑模式，再右键分区新增分割线。");
            return;
        }
        if (sender is not MenuItem item)
        {
            SetStatus("无法识别目标分区；没有修改布局。");
            return;
        }
        var menu = item.Parent as ContextMenu ?? ItemsControl.ItemsControlFromItemContainer(item) as ContextMenu;
        if (menu?.PlacementTarget is not FrameworkElement target || !_regionLeafMap.TryGetValue(target, out var info))
        {
            SetStatus("无法识别目标分区；没有修改布局。");
            return;
        }
        var orientation = string.Equals(item.Tag?.ToString(), "Horizontal", StringComparison.OrdinalIgnoreCase) ? "Horizontal" : "Vertical";
        var split = new RegionSplitNode
        {
            Orientation = orientation,
            Ratio = 0.5,
            First = info.Node,
            Second = new RegionSplitNode { ContentKey = "__empty__" }
        };
        var root = _regionRoots[info.RootKey];
        if (!TryReplaceNode(root, info.Node, split, out var updatedRoot))
        {
            SetStatus("无法安全更新分区树；布局未更改。");
            return;
        }
        _regionRoots[info.RootKey] = updatedRoot;
        RebuildRegionRoot(info.RootKey);
        SaveLayout();
        SetStatus(orientation == "Horizontal" ? "已新增横向分割线；可拖动调整，右键分割线可合并。" : "已新增纵向分割线；可拖动调整，右键分割线可合并。");
    }

    private void DeleteSplit_Click(object sender, RoutedEventArgs e)
    {
        if (!_isEditing || sender is not MenuItem item)
        {
            SetStatus("请在编辑模式下右键分割线进行合并。");
            return;
        }
        var menu = item.Parent as ContextMenu ?? ItemsControl.ItemsControlFromItemContainer(item) as ContextMenu;
        if (menu?.PlacementTarget is not GridSplitter splitter || splitter.Parent is not Grid host || host.Tag is not RegionSplitNode node)
        {
            SetStatus("无法识别目标分割线；没有修改布局。");
            return;
        }
        if (!_regionElementRootKeys.TryGetValue(host, out var rootKey))
        {
            SetStatus("无法识别分区；没有删除分割线。");
            return;
        }
        var firstEmpty = IsEmptyRegionNode(node.First);
        var secondEmpty = IsEmptyRegionNode(node.Second);
        if (!firstEmpty && !secondEmpty)
        {
            MessageBox.Show(this, "分割线两侧都包含分区内容。为避免丢失内容，当前原型不会强行合并；请先将一侧整理为空白分区。", "无法安全合并", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        var survivor = firstEmpty && !secondEmpty ? node.Second! : node.First!;
        if (!TryReplaceNode(_regionRoots[rootKey], node, survivor, out var updatedRoot))
        {
            SetStatus("合并失败；原布局保持不变。");
            return;
        }
        _regionRoots[rootKey] = updatedRoot;
        RebuildRegionRoot(rootKey);
        SaveLayout();
        SetStatus("分割线已删除，原有内容与剩余分区已保留。");
    }

    private static bool IsEmptyRegionNode(RegionSplitNode? node)
    {
        if (node is null) return true;
        if (string.IsNullOrWhiteSpace(node.Orientation)) return node.ContentKey == "__empty__";
        return IsEmptyRegionNode(node.First) && IsEmptyRegionNode(node.Second);
    }

    private static bool TryReplaceNode(RegionSplitNode current, RegionSplitNode target, RegionSplitNode replacement, out RegionSplitNode result)
    {
        if (ReferenceEquals(current, target)) { result = replacement; return true; }
        if (current.First is not null && TryReplaceNode(current.First, target, replacement, out var first))
        {
            current.First = first; result = current; return true;
        }
        if (current.Second is not null && TryReplaceNode(current.Second, target, replacement, out var second))
        {
            current.Second = second; result = current; return true;
        }
        result = current;
        return false;
    }

    private void RebuildRegionRoot(string rootKey)
    {
        var outer = _regionOuterGrids[rootKey];
        var oldVisual = _regionVisualRoots[rootKey];
        var originalPanel = _regionContentPanels[rootKey];
        var row = Grid.GetRow(oldVisual);
        var column = Grid.GetColumn(oldVisual);
        var rowSpan = Grid.GetRowSpan(oldVisual);
        var columnSpan = Grid.GetColumnSpan(oldVisual);
        var index = outer.Children.IndexOf(oldVisual);
        if (originalPanel.Parent is Panel panelParent) panelParent.Children.Remove(originalPanel);
        if (oldVisual.Parent is Panel oldParent) oldParent.Children.Remove(oldVisual);
        foreach (var key in _regionLeafMap.Keys.Where(k => _regionLeafMap[k].RootKey == rootKey).ToList()) _regionLeafMap.Remove(key);
        foreach (var key in _regionElementRootKeys.Where(kv => kv.Value == rootKey).Select(kv => kv.Key).ToList()) _regionElementRootKeys.Remove(key);
        foreach (var splitter in _dynamicSplitterRootKeys.Where(kv => kv.Value == rootKey).Select(kv => kv.Key).ToList())
        {
            _dividerViews.Remove(splitter.Uid);
            _dynamicSplitterRootKeys.Remove(splitter);
            _dynamicSplitters.Remove(splitter);
        }
        var visual = BuildRegionVisual(_regionRoots[rootKey], rootKey, originalPanel);
        Grid.SetRow(visual, row); Grid.SetColumn(visual, column); Grid.SetRowSpan(visual, rowSpan); Grid.SetColumnSpan(visual, columnSpan);
        outer.Children.Insert(Math.Clamp(index, 0, outer.Children.Count), visual);
        _regionVisualRoots[rootKey] = visual;
        CreateDividerLayout();
    }

    private static readonly Dictionary<string, double> DefaultFontSizes = new()
    {
        ["SectionTitle"] = 19, ["GeneralText"] = 12, ["AppName"] = 12,
        ["TodoText"] = 13, ["FileName"] = 12, ["FilePath"] = 10,
        ["Clock"] = 30, ["Date"] = 12, ["WeatherText"] = 12,
        ["ToolbarText"] = 12, ["StatusText"] = 11
    };

    private static void EnsureFontDefaults(Dictionary<string, double> sizes)
    {
        foreach (var item in DefaultFontSizes)
            if (!sizes.ContainsKey(item.Key) || double.IsNaN(sizes[item.Key]) || sizes[item.Key] < 8 || sizes[item.Key] > 48)
                sizes[item.Key] = item.Value;
    }

    private static readonly string[] RegionOpacityKeys = ["ApplicationsRegion", "TodoRegion", "ReferencesRegion", "ClockWeatherRegion"];

    private static void EnsureRegionOpacityDefaults(Dictionary<string, double> values)
    {
        foreach (var key in RegionOpacityKeys)
            if (!values.ContainsKey(key) || double.IsNaN(values[key]) || values[key] < 0 || values[key] > 100)
                values[key] = 65;
    }

    private static bool TryParseHexColor(string? value, out Color color)
    {
        color = Color.FromRgb(32, 38, 48);
        if (string.IsNullOrWhiteSpace(value)) return false;
        var hex = value.Trim();
        if (hex.StartsWith('#')) hex = hex[1..];
        if (hex.Length != 6) return false;
        try
        {
            var r = byte.Parse(hex.Substring(0, 2), System.Globalization.NumberStyles.HexNumber);
            var g = byte.Parse(hex.Substring(2, 2), System.Globalization.NumberStyles.HexNumber);
            var b = byte.Parse(hex.Substring(4, 2), System.Globalization.NumberStyles.HexNumber);
            color = Color.FromRgb(r, g, b);
            return true;
        }
        catch { return false; }
    }

    private static string NormalizeHexColor(string? value, string fallback)
    {
        return TryParseHexColor(value, out var color) ? $"#{color.R:X2}{color.G:X2}{color.B:X2}" : fallback;
    }

    private Color GetRegionPanelColor(string key)
    {
        var baseColor = TryParseHexColor(_layout?.BackgroundColorHex, out var parsed) ? parsed : Color.FromRgb(32, 38, 48);
        var percent = _layout?.RegionOpacities is not null && _layout.RegionOpacities.TryGetValue(key, out var opacity)
            ? Math.Clamp(opacity, 0, 100) : 65;
        var alpha = (byte)Math.Round(255 * percent / 100.0);
        return Color.FromArgb(alpha, baseColor.R, baseColor.G, baseColor.B);
    }

    private void ApplyBackgroundAppearance()
    {
        var color = TryParseHexColor(_layout?.BackgroundColorHex, out var parsed) ? parsed : Color.FromRgb(32, 38, 48);
        var brush = new SolidColorBrush(color);
        RootGrid.Background = brush;
        Background = brush;
    }

    private void ApplyPanelAppearance()
    {
        if (_layout is null) return;
        ApplicationsRegion.Background = new SolidColorBrush(GetRegionPanelColor("ApplicationsRegion"));
        TodoRegion.Background = new SolidColorBrush(GetRegionPanelColor("TodoRegion"));
        ReferencesRegion.Background = new SolidColorBrush(GetRegionPanelColor("ReferencesRegion"));
        ClockWeatherRegion.Background = new SolidColorBrush(GetRegionPanelColor("ClockWeatherRegion"));
        var average = RegionOpacityKeys.Average(k => _layout.RegionOpacities.TryGetValue(k, out var value) ? value : 65);
        var color = TryParseHexColor(_layout.BackgroundColorHex, out var parsed) ? parsed : Color.FromRgb(32, 38, 48);
        StatusBarBorder.Background = new SolidColorBrush(Color.FromArgb((byte)Math.Round(255 * average / 100.0), color.R, color.G, color.B));
    }

    private static void ApplyDarkComboBoxTheme(ComboBox combo)
    {
        var dark = new SolidColorBrush(Color.FromRgb(32, 38, 48));
        combo.Background = dark;
        combo.Foreground = new SolidColorBrush(Color.FromRgb(238, 242, 247));
        combo.BorderBrush = new SolidColorBrush(Color.FromRgb(76, 88, 104));
        combo.BorderThickness = new Thickness(1);
        combo.Template = (ControlTemplate)Application.Current.FindResource("DarkComboBoxTemplate");
        combo.ItemContainerStyle = (Style)Application.Current.FindResource("DarkComboBoxItemStyle");
        combo.Resources[SystemColors.WindowBrushKey] = dark;
        combo.Resources[SystemColors.WindowTextBrushKey] = new SolidColorBrush(Color.FromRgb(238, 242, 247));
        combo.Resources[SystemColors.HighlightBrushKey] = new SolidColorBrush(Color.FromRgb(42, 83, 105));
        combo.Resources[SystemColors.HighlightTextBrushKey] = Brushes.White;
    }

    private void AnyElement_Loaded(object sender, RoutedEventArgs e)
    {
        if (e.OriginalSource is FrameworkElement element) ApplyIndividualFontSizesRecursive(element);
    }

    private void ApplyIndividualFontSizes() => ApplyIndividualFontSizesRecursive(RootGrid);

    private void ApplyIndividualFontSizesRecursive(FrameworkElement element)
    {
        if (element.Tag is string category && _layout is not null && _layout.FontSizes.TryGetValue(category, out var size))
        {
            var clamped = Math.Clamp(size, 8, 48);
            if (element is TextBlock textBlock) textBlock.FontSize = clamped;
            else if (element is Control control) control.FontSize = clamped;
        }
        var count = VisualTreeHelper.GetChildrenCount(element);
        for (var i = 0; i < count; i++)
            if (VisualTreeHelper.GetChild(element, i) is FrameworkElement child) ApplyIndividualFontSizesRecursive(child);
    }

    private sealed class FontOption
    {
        public string Label { get; }
        public string Key { get; }
        public FontOption(string label, string key) { Label = label; Key = key; }
        public override string ToString() => Label;
    }

    private void FontSizeButton_Click(object sender, RoutedEventArgs e)
    {
        if (_layout is null) return;
        var original = new Dictionary<string, double>(_layout.FontSizes);
        var accepted = false;
        var options = new List<FontOption>
        {
            new("分类标题", "SectionTitle"), new("普通文字", "GeneralText"),
            new("应用名称", "AppName"), new("待办事项", "TodoText"),
            new("文件名称", "FileName"), new("文件路径", "FilePath"),
            new("时钟", "Clock"), new("日期", "Date"),
            new("天气与城市", "WeatherText"), new("顶部操作按钮", "ToolbarText"),
            new("底部状态文字", "StatusText")
        };
        var dialog = new Window
        {
            Title = "分别调整字体大小", Owner = this, Width = 430, Height = 300,
            ResizeMode = ResizeMode.NoResize, WindowStartupLocation = WindowStartupLocation.CenterOwner,
            Background = new SolidColorBrush(Color.FromRgb(16, 19, 24)),
            Foreground = new SolidColorBrush(Color.FromRgb(238, 242, 247))
        };
        var panel = new StackPanel { Margin = new Thickness(18) };
        panel.Children.Add(new TextBlock { Text = "选择要调整的文字类别", FontSize = 13, Margin = new Thickness(0, 0, 0, 6) });
        var combo = new ComboBox { ItemsSource = options, DisplayMemberPath = nameof(FontOption.Label), SelectedIndex = 0, Height = 32, Margin = new Thickness(0, 0, 0, 12) };
        ApplyDarkComboBoxTheme(combo);
        var label = new TextBlock { FontSize = 14, Margin = new Thickness(0, 0, 0, 6) };
        var slider = new Slider { Minimum = 8, Maximum = 48, Value = _layout.FontSizes[options[0].Key], TickFrequency = 1, IsSnapToTickEnabled = true, Margin = new Thickness(0, 0, 0, 14) };
        void UpdateLabel() => label.Text = $"{((FontOption)combo.SelectedItem).Label}：{Math.Round(slider.Value)} px";
        combo.SelectionChanged += (_, _) =>
        {
            if (combo.SelectedItem is not FontOption option) return;
            _fontDialogUpdating = true;
            slider.Value = _layout.FontSizes.TryGetValue(option.Key, out var current) ? current : DefaultFontSizes[option.Key];
            _fontDialogUpdating = false;
            UpdateLabel();
        };
        slider.ValueChanged += (_, _) =>
        {
            if (_fontDialogUpdating || combo.SelectedItem is not FontOption option) return;
            _layout.FontSizes[option.Key] = slider.Value;
            UpdateLabel();
            ApplyIndividualFontSizes();
        };
        UpdateLabel();
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
        var cancel = new Button { Content = "取消", Style = (Style)FindResource("ToolbarButton"), MinWidth = 76, Margin = new Thickness(0, 0, 8, 0) };
        cancel.Click += (_, _) => { dialog.DialogResult = false; };
        var apply = new Button { Content = "保存", Style = (Style)FindResource("ToolbarButton"), MinWidth = 76 };
        apply.Click += (_, _) => { accepted = true; SaveLayout(); dialog.DialogResult = true; };
        dialog.Closed += (_, _) => { if (!accepted) { _layout.FontSizes = new Dictionary<string, double>(original); ApplyIndividualFontSizes(); } };
        buttons.Children.Add(cancel); buttons.Children.Add(apply);
        panel.Children.Add(combo); panel.Children.Add(label); panel.Children.Add(slider); panel.Children.Add(buttons);
        dialog.Content = panel;
        dialog.ShowDialog();
    }

    private void RootGrid_SizeChanged(object sender, SizeChangedEventArgs e) => ApplyNeonDimensions();

    private void ApplyNeonDimensions()
    {
        if (_layout is null || RootGrid.ActualWidth <= 0) return;
        NeonBar.Width = Math.Max(120, RootGrid.ActualWidth * Math.Clamp(_layout.NeonLengthPercent, 20, 100) / 100.0);
        NeonBar.Height = Math.Clamp(_layout.NeonThickness, 2, 20);
        NeonBar.HorizontalAlignment = HorizontalAlignment.Center;
    }

    private void ApplyToolbarSpacing()
    {
        if (ToolbarGrid is null) return;

        // NeonBar uses a 14 px glow. Keep an 8 px visible gap from the glow to the controls,
        // matching the 8 px gap from the controls to the bottom edge of the toolbar background.
        const double sideGap = 16;
        const double bottomGap = 8;
        const double neonGlowBlur = 14;
        var topGap = _layout?.NeonEnabled == true ? bottomGap + neonGlowBlur : bottomGap;
        ToolbarGrid.Margin = new Thickness(sideGap, topGap, sideGap, bottomGap);
    }

    private void NeonSettingsButton_Click(object sender, RoutedEventArgs e)
    {
        if (_layout is null) return;
        var oldLength = _layout.NeonLengthPercent;
        var oldThickness = _layout.NeonThickness;
        var accepted = false;
        var dialog = new Window
        {
            Title = "霓虹灯设置", Owner = this, Width = 430, Height = 270,
            ResizeMode = ResizeMode.NoResize, WindowStartupLocation = WindowStartupLocation.CenterOwner,
            Background = new SolidColorBrush(Color.FromRgb(16, 19, 24)),
            Foreground = new SolidColorBrush(Color.FromRgb(238, 242, 247))
        };
        var panel = new StackPanel { Margin = new Thickness(18) };
        var lengthLabel = new TextBlock { Margin = new Thickness(0, 0, 0, 5) };
        var lengthSlider = new Slider { Minimum = 20, Maximum = 100, Value = oldLength, TickFrequency = 5, IsSnapToTickEnabled = false, Margin = new Thickness(0, 0, 0, 15) };
        var thicknessLabel = new TextBlock { Margin = new Thickness(0, 0, 0, 5) };
        var thicknessSlider = new Slider { Minimum = 2, Maximum = 20, Value = oldThickness, TickFrequency = 1, IsSnapToTickEnabled = true, Margin = new Thickness(0, 0, 0, 15) };
        void RefreshPreview()
        {
            lengthLabel.Text = $"霓虹灯长度：{Math.Round(lengthSlider.Value)}% 窗口宽度";
            thicknessLabel.Text = $"霓虹灯粗细：{Math.Round(thicknessSlider.Value)} px";
            _layout.NeonLengthPercent = lengthSlider.Value;
            _layout.NeonThickness = thicknessSlider.Value;
            ApplyNeonDimensions();
        }
        lengthSlider.ValueChanged += (_, _) => RefreshPreview();
        thicknessSlider.ValueChanged += (_, _) => RefreshPreview();
        RefreshPreview();
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
        var cancel = new Button { Content = "取消", Style = (Style)FindResource("ToolbarButton"), MinWidth = 76, Margin = new Thickness(0, 0, 8, 0) };
        cancel.Click += (_, _) => { dialog.DialogResult = false; };
        var apply = new Button { Content = "保存", Style = (Style)FindResource("ToolbarButton"), MinWidth = 76 };
        apply.Click += (_, _) => { accepted = true; SaveLayout(); dialog.DialogResult = true; };
        dialog.Closed += (_, _) => { if (!accepted) { _layout.NeonLengthPercent = oldLength; _layout.NeonThickness = oldThickness; ApplyNeonDimensions(); } };
        buttons.Children.Add(cancel); buttons.Children.Add(apply);
        panel.Children.Add(lengthLabel); panel.Children.Add(lengthSlider); panel.Children.Add(thicknessLabel); panel.Children.Add(thicknessSlider); panel.Children.Add(buttons);
        dialog.Content = panel;
        dialog.ShowDialog();
    }

    private void WindowDragArea_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ChangedButton != MouseButton.Left) return;
        if (e.ClickCount == 2)
        {
            WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
            return;
        }
        try { DragMove(); } catch { /* click may finish before dragging starts */ }
    }

    private void ExitButton_Click(object sender, RoutedEventArgs e) => Close();

    private static T? FindVisualAncestor<T>(DependencyObject? current) where T : DependencyObject
    {
        while (current is not null)
        {
            if (current is T match) return match;
            current = current is Visual ? VisualTreeHelper.GetParent(current) : LogicalTreeHelper.GetParent(current);
        }
        return null;
    }

    private void MinimizeWindow_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
    private void ToggleMaximizeWindow_Click(object sender, RoutedEventArgs e) => WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
    private void CloseWindow_Click(object sender, RoutedEventArgs e) => Close();

    private void EditModeButton_Click(object sender, RoutedEventArgs e) => SetEditMode(!_isEditing);
    private void ContextEdit_Click(object sender, RoutedEventArgs e) => SetEditMode(!_isEditing);

    private void AddShortcutButton_Click(object sender, RoutedEventArgs e)
    {
        if (!_isEditing) return;
        var dialog = new OpenFileDialog
        {
            Title = "选择应用程序或快捷方式（只创建引用，不移动文件）",
            Filter = "应用与快捷方式 (*.lnk;*.url;*.exe)|*.lnk;*.url;*.exe|所有文件 (*.*)|*.*",
            Multiselect = true,
            CheckFileExists = true
        };
        if (dialog.ShowDialog(this) != true) return;
        foreach (var path in dialog.FileNames)
        {
            if (_shortcuts.Any(s => string.Equals(s.Path, path, StringComparison.OrdinalIgnoreCase))) continue;
            _shortcuts.Add(new ShortcutEntry
            {
                Name = Path.GetFileNameWithoutExtension(path),
                Path = path,
                Icon = Path.GetExtension(path).ToLowerInvariant() switch { ".url" => "🌐", ".lnk" => "🔗", _ => "▣" }
            });
        }
        SaveLayout();
        SetStatus("已添加快捷方式引用；未移动应用安装目录或原文件。");
    }

    private void AddFileButton_Click(object sender, RoutedEventArgs e)
    {
        if (!_isEditing) return;
        var dialog = new OpenFileDialog { Title = "选择文件（仅添加路径引用）", Filter = "所有文件 (*.*)|*.*", Multiselect = true, CheckFileExists = true };
        if (dialog.ShowDialog(this) != true) return;
        foreach (var path in dialog.FileNames)
        {
            if (_fileReferences.Any(f => string.Equals(f.Path, path, StringComparison.OrdinalIgnoreCase))) continue;
            _fileReferences.Add(new FileReferenceEntry { Name = Path.GetFileName(path), Path = path });
        }
        SaveLayout();
        SetStatus("已添加文件引用；没有移动、覆盖或删除任何真实文件。");
    }

    private void ShortcutItem_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (sender is Button { Tag: ShortcutEntry item })
        {
            _shortcutDragCandidate = item;
            _shortcutDragStartPoint = e.GetPosition(this);
        }
        else
        {
            _shortcutDragCandidate = null;
        }
    }

    private void ShortcutItem_PreviewMouseMove(object sender, MouseEventArgs e)
    {
        if (e.LeftButton != MouseButtonState.Pressed ||
            _shortcutDragCandidate is not ShortcutEntry item ||
            sender is not Button sourceButton)
            return;

        var current = e.GetPosition(this);
        if (Math.Abs(current.X - _shortcutDragStartPoint.X) < SystemParameters.MinimumHorizontalDragDistance &&
            Math.Abs(current.Y - _shortcutDragStartPoint.Y) < SystemParameters.MinimumVerticalDragDistance)
            return;

        _shortcutDragCandidate = null;
        _lastShortcutDragUtc = DateTime.UtcNow;
        try
        {
            e.Handled = true;
            DragDrop.DoDragDrop(sourceButton, item, DragDropEffects.Move);
        }
        finally
        {
            _shortcutDragCandidate = null;
        }
    }

    private void ShortcutItem_DragOver(object sender, DragEventArgs e)
    {
        e.Effects = e.Data.GetDataPresent(typeof(ShortcutEntry)) ? DragDropEffects.Move : DragDropEffects.None;
        e.Handled = true;
    }

    private void ShortcutItem_Drop(object sender, DragEventArgs e)
    {
        if (e.Data.GetData(typeof(ShortcutEntry)) is not ShortcutEntry source ||
            sender is not Button { Tag: ShortcutEntry target })
        {
            e.Effects = DragDropEffects.None;
            e.Handled = true;
            return;
        }

        var sourceIndex = _shortcuts.IndexOf(source);
        var targetIndex = _shortcuts.IndexOf(target);
        if (sourceIndex >= 0 && targetIndex >= 0 && sourceIndex != targetIndex)
        {
            _shortcuts.Move(sourceIndex, targetIndex);
            SaveLayout();
            SetStatus($"已调整快捷方式顺序：{source.Name}。新顺序已保存。");
        }

        _lastShortcutDragUtc = DateTime.UtcNow;
        e.Effects = DragDropEffects.Move;
        e.Handled = true;
    }

    private void ShortcutButton_Click(object sender, RoutedEventArgs e)
    {
        if ((DateTime.UtcNow - _lastShortcutDragUtc).TotalMilliseconds < 700) return;
        if (sender is not Button { Tag: ShortcutEntry item }) return;
        try
        {
            Process.Start(new ProcessStartInfo(item.Path) { UseShellExecute = true });
            SetStatus($"已请求打开：{item.Name}");
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, $"无法打开“{item.Name}”。\n\n{ex.Message}\n\n如果路径已经变化，请在编辑模式中重新添加快捷方式。", "打开失败", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private void FileReferenceButton_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not Button { Tag: FileReferenceEntry item }) return;
        try
        {
            if (!File.Exists(item.Path))
            {
                MessageBox.Show(this, $"找不到文件：\n{item.Path}\n\n本原型不会自动移动文件。请在编辑模式中重新添加有效引用。", "引用失效", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            Process.Start(new ProcessStartInfo(item.Path) { UseShellExecute = true });
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, $"无法打开文件引用。\n{ex.Message}", "打开失败", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private void AddTodoButton_Click(object sender, RoutedEventArgs e)
    {
        var todo = new TodoEntry { Text = "新任务" };
        _todos.Add(todo);
        SaveLayout();
        SetStatus("已添加任务；双击任务文字可编辑。");
    }

    private void Todos_CollectionChanged(object? sender, NotifyCollectionChangedEventArgs e)
    {
        if (e.OldItems is not null) foreach (TodoEntry item in e.OldItems) item.PropertyChanged -= Todo_PropertyChanged;
        if (e.NewItems is not null) foreach (TodoEntry item in e.NewItems) item.PropertyChanged += Todo_PropertyChanged;
        SaveLayout();
    }

    private void Collections_Changed(object? sender, NotifyCollectionChangedEventArgs e) => SaveLayout();
    private void Todo_PropertyChanged(object? sender, PropertyChangedEventArgs e)
    {
        // Completion changes only the checkbox/strikethrough. Preserve the task's current position.
        SaveLayout();
    }

    private void TodoDisplay_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ClickCount < 2 || sender is not TextBlock display || display.DataContext is not TodoEntry item) return;
        item.IsEditing = true;
        if (VisualTreeHelper.GetParent(display) is Grid parent)
        {
            Dispatcher.BeginInvoke(DispatcherPriority.Input, new Action(() =>
            {
                var box = FindVisualChild<TextBox>(parent);
                if (box is null) return;
                box.Focus();
                box.SelectAll();
            }));
        }
        e.Handled = true;
    }

    private void TodoText_LostFocus(object sender, RoutedEventArgs e)
    {
        if (sender is TextBox { DataContext: TodoEntry item }) item.IsEditing = false;
        SaveLayout();
    }

    private void TodoText_KeyDown(object sender, KeyEventArgs e)
    {
        if ((e.Key == Key.Enter || e.Key == Key.Escape) && sender is TextBox { DataContext: TodoEntry item })
        {
            item.IsEditing = false;
            Keyboard.ClearFocus();
            SaveLayout();
            e.Handled = true;
        }
    }

    private static T? FindVisualChild<T>(DependencyObject parent) where T : DependencyObject
    {
        var count = VisualTreeHelper.GetChildrenCount(parent);
        for (var i = 0; i < count; i++)
        {
            var child = VisualTreeHelper.GetChild(parent, i);
            if (child is T match) return match;
            var nested = FindVisualChild<T>(child);
            if (nested is not null) return nested;
        }
        return null;
    }

    private sealed class BackgroundThemeOption
    {
        public string Label { get; }
        public string Key { get; }
        public string Hex { get; }
        public BackgroundThemeOption(string label, string key, string hex) { Label = label; Key = key; Hex = hex; }
        public override string ToString() => Label;
    }

    private sealed class BackgroundScopeOption
    {
        public string Label { get; }
        public string Key { get; }
        public BackgroundScopeOption(string label, string key) { Label = label; Key = key; }
        public override string ToString() => Label;
    }

    private void BackgroundButton_Click(object sender, RoutedEventArgs e)
    {
        if (_layout is null) return;
        var oldTheme = _layout.BackgroundTheme;
        var oldColor = _layout.BackgroundColorHex;
        var oldPhotoOpacity = _layout.PhotoOpacityPercent;
        var oldImagePath = _layout.BackgroundImagePath;
        var oldOpacities = new Dictionary<string, double>(_layout.RegionOpacities);
        var accepted = false;
        var updating = false;

        var dialog = new Window
        {
            Title = "背景与透明度设置", Owner = this, Width = 560, Height = 570,
            ResizeMode = ResizeMode.NoResize, WindowStartupLocation = WindowStartupLocation.CenterOwner,
            Background = new SolidColorBrush(Color.FromRgb(16, 19, 24)),
            Foreground = new SolidColorBrush(Color.FromRgb(238, 242, 247))
        };
        var panel = new StackPanel { Margin = new Thickness(18) };
        panel.Children.Add(new TextBlock { Text = "底色主题", FontSize = 14, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 0, 0, 7) });
        var themes = new List<BackgroundThemeOption>
        {
            new("高级深灰", "DarkGray", "#202630"),
            new("极简纯黑", "PureBlack", "#000000"),
            new("冷色深蓝灰", "BlueGray", "#111D2B"),
            new("照片背景概念", "Photo", "#18202B"),
            new("自定义颜色", "Custom", _layout.BackgroundColorHex)
        };
        var themeCombo = new ComboBox { ItemsSource = themes, DisplayMemberPath = nameof(BackgroundThemeOption.Label), Height = 32, Margin = new Thickness(0, 0, 0, 10) };
        ApplyDarkComboBoxTheme(themeCombo);
        themeCombo.SelectedItem = themes.FirstOrDefault(t => t.Key == _layout.BackgroundTheme) ?? themes[0];
        panel.Children.Add(themeCombo);

        panel.Children.Add(new TextBlock { Text = "自定义底色（HEX，例如 #202630）", FontSize = 12, Margin = new Thickness(0, 0, 0, 5) });
        var colorRow = new DockPanel { Margin = new Thickness(0, 0, 0, 12) };
        var colorPreview = new Border { Width = 36, Height = 30, CornerRadius = new CornerRadius(4), BorderBrush = new SolidColorBrush(Color.FromRgb(76, 88, 104)), BorderThickness = new Thickness(1), Margin = new Thickness(0, 0, 8, 0) };
        DockPanel.SetDock(colorPreview, Dock.Left);
        var colorBox = new TextBox { Text = _layout.BackgroundColorHex, Height = 30, VerticalContentAlignment = VerticalAlignment.Center };
        colorBox.Style = (Style)FindResource("DarkTextBox");
        colorRow.Children.Add(colorPreview); colorRow.Children.Add(colorBox);
        panel.Children.Add(colorRow);

        panel.Children.Add(new TextBlock { Text = "透明度作用范围", FontSize = 12, Margin = new Thickness(0, 0, 0, 5) });
        var scopes = new List<BackgroundScopeOption>
        {
            new("全部分区", "*"), new("常用应用", "ApplicationsRegion"),
            new("待办事项", "TodoRegion"), new("文件与项目", "ReferencesRegion"),
            new("时间与天气", "ClockWeatherRegion")
        };
        var scopeCombo = new ComboBox { ItemsSource = scopes, DisplayMemberPath = nameof(BackgroundScopeOption.Label), SelectedIndex = 0, Height = 32, Margin = new Thickness(0, 0, 0, 8) };
        ApplyDarkComboBoxTheme(scopeCombo);
        panel.Children.Add(scopeCombo);
        var opacityLabel = new TextBlock { FontSize = 12, Margin = new Thickness(0, 0, 0, 4) };
        var opacitySlider = new Slider { Minimum = 0, Maximum = 100, TickFrequency = 5, Value = 65, Margin = new Thickness(0, 0, 0, 12) };
        panel.Children.Add(opacityLabel); panel.Children.Add(opacitySlider);

        var photoLabel = new TextBlock { FontSize = 12, Margin = new Thickness(0, 0, 0, 4) };
        var photoSlider = new Slider { Minimum = 0, Maximum = 100, TickFrequency = 5, Value = _layout.PhotoOpacityPercent, Margin = new Thickness(0, 0, 0, 12) };
        panel.Children.Add(photoLabel); panel.Children.Add(photoSlider);

        var photoButtons = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 14) };
        var choosePhoto = new Button { Content = "选择背景照片…", Style = (Style)FindResource("ToolbarButton"), Margin = new Thickness(0, 0, 8, 0) };
        var clearPhoto = new Button { Content = "移除照片", Style = (Style)FindResource("ToolbarButton") };
        photoButtons.Children.Add(choosePhoto); photoButtons.Children.Add(clearPhoto); panel.Children.Add(photoButtons);
        var actionButtons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
        var cancel = new Button { Content = "取消", Style = (Style)FindResource("ToolbarButton"), MinWidth = 76, Margin = new Thickness(0, 0, 8, 0) };
        var save = new Button { Content = "保存", Style = (Style)FindResource("ToolbarButton"), MinWidth = 76 };
        actionButtons.Children.Add(cancel); actionButtons.Children.Add(save); panel.Children.Add(actionButtons);

        void UpdateColorPreview()
        {
            if (TryParseHexColor(colorBox.Text, out var color)) colorPreview.Background = new SolidColorBrush(color);
        }
        void ApplyThemeChoice()
        {
            if (themeCombo.SelectedItem is not BackgroundThemeOption theme) return;
            updating = true;
            _layout.BackgroundTheme = theme.Key;
            _layout.BackgroundColorHex = theme.Key == "Custom" ? NormalizeHexColor(colorBox.Text, theme.Hex) : theme.Hex;
            colorBox.Text = _layout.BackgroundColorHex;
            updating = false;
            UpdateColorPreview();
            ApplyBackgroundAppearance(); ApplyPanelAppearance();
        }
        void RefreshOpacity()
        {
            if (scopeCombo.SelectedItem is not BackgroundScopeOption scope) return;
            var percent = Math.Clamp(opacitySlider.Value, 0, 100);
            opacityLabel.Text = $"分区底色不透明度：{Math.Round(percent)}%（数值越低，背景照片越清晰）";
            if (scope.Key == "*")
                foreach (var key in RegionOpacityKeys) _layout.RegionOpacities[key] = percent;
            else _layout.RegionOpacities[scope.Key] = percent;
            ApplyPanelAppearance();
        }
        void RefreshPhotoOpacity()
        {
            _layout.PhotoOpacityPercent = Math.Clamp(photoSlider.Value, 0, 100);
            photoLabel.Text = $"背景照片可见度：{Math.Round(photoSlider.Value)}%";
            BackgroundImage.Opacity = _layout.PhotoOpacityPercent / 100.0;
        }
        void RefreshScopeSlider()
        {
            if (scopeCombo.SelectedItem is not BackgroundScopeOption scope) return;
            updating = true;
            opacitySlider.Value = scope.Key == "*"
                ? RegionOpacityKeys.Average(k => _layout.RegionOpacities.TryGetValue(k, out var v) ? v : 65)
                : (_layout.RegionOpacities.TryGetValue(scope.Key, out var v) ? v : 65);
            updating = false;
            opacityLabel.Text = $"分区底色不透明度：{Math.Round(opacitySlider.Value)}%（数值越低，背景照片越清晰）";
        }
        themeCombo.SelectionChanged += (_, _) => { if (!updating) ApplyThemeChoice(); };
        colorBox.TextChanged += (_, _) =>
        {
            if (updating || !TryParseHexColor(colorBox.Text, out var color)) return;
            _layout.BackgroundTheme = "Custom";
            _layout.BackgroundColorHex = $"#{color.R:X2}{color.G:X2}{color.B:X2}";
            updating = true;
            themeCombo.SelectedItem = themes.Last();
            updating = false;
            UpdateColorPreview(); ApplyBackgroundAppearance(); ApplyPanelAppearance();
        };
        scopeCombo.SelectionChanged += (_, _) => RefreshScopeSlider();
        opacitySlider.ValueChanged += (_, _) => { if (!updating) RefreshOpacity(); };
        photoSlider.ValueChanged += (_, _) => RefreshPhotoOpacity();
        choosePhoto.Click += (_, _) =>
        {
            var fileDialog = new OpenFileDialog { Title = "选择桌面背景照片", Filter = "图片文件 (*.jpg;*.jpeg;*.png;*.bmp;*.webp)|*.jpg;*.jpeg;*.png;*.bmp;*.webp|所有文件 (*.*)|*.*", CheckFileExists = true };
            if (fileDialog.ShowDialog(dialog) != true) return;
            _layout.BackgroundImagePath = fileDialog.FileName;
            ApplyBackground(fileDialog.FileName, showMissingWarning: false);
        };
        clearPhoto.Click += (_, _) => { _layout.BackgroundImagePath = null; ApplyBackground(null, showMissingWarning: false); };
        cancel.Click += (_, _) => dialog.DialogResult = false;
        save.Click += (_, _) => { accepted = true; SaveLayout(); dialog.DialogResult = true; };
        dialog.Closed += (_, _) =>
        {
            if (accepted) return;
            _layout.BackgroundTheme = oldTheme;
            _layout.BackgroundColorHex = oldColor;
            _layout.PhotoOpacityPercent = oldPhotoOpacity;
            _layout.BackgroundImagePath = oldImagePath;
            _layout.RegionOpacities = oldOpacities;
            ApplyBackgroundAppearance(); ApplyPanelAppearance(); ApplyBackground(oldImagePath, showMissingWarning: false);
        };
        ApplyThemeChoice(); RefreshScopeSlider(); RefreshPhotoOpacity(); UpdateColorPreview();
        dialog.Content = panel;
        dialog.ShowDialog();
    }

    private void ApplyBackground(string? path, bool showMissingWarning)
    {
        BackgroundImage.Source = null;
        BackgroundImage.Opacity = Math.Clamp(_layout?.PhotoOpacityPercent ?? 100, 0, 100) / 100.0;
        ApplyBackgroundAppearance();
        ApplyPanelAppearance();
        if (string.IsNullOrWhiteSpace(path)) return;
        try
        {
            if (!File.Exists(path))
            {
                if (showMissingWarning) SetStatus("背景照片缺失，已使用当前底色；原图片路径引用仍保留。");
                return;
            }
            var image = new BitmapImage();
            image.BeginInit();
            image.CacheOption = BitmapCacheOption.OnLoad;
            image.UriSource = new Uri(path, UriKind.Absolute);
            image.EndInit();
            image.Freeze();
            BackgroundImage.Source = image;
        }
        catch
        {
            BackgroundImage.Source = null;
            if (showMissingWarning) SetStatus("背景照片无法读取，已使用当前底色；原图片路径引用仍保留。");
        }
    }

    private void NeonToggleButton_Click(object sender, RoutedEventArgs e)
    {
        NeonBar.Visibility = NeonBar.Visibility == Visibility.Visible ? Visibility.Collapsed : Visibility.Visible;
        _layout!.NeonEnabled = NeonBar.Visibility == Visibility.Visible;
        ApplyToolbarSpacing();
        NeonToggleButton.Content = _layout.NeonEnabled ? "关闭霓虹" : "开启霓虹";
        SaveLayout();
    }

    private void CityTextBox_TextChanged(object sender, TextChangedEventArgs e)
    {
        if (_isLoadingLayout || _layout is null) return;
        _layout.City = CityTextBox.Text.Trim();
        SaveLayout();
    }

    private void TimeButton_Click(object sender, RoutedEventArgs e) => OpenEdgeSearch("time in " + GetCity());

    private string GetCity() => string.IsNullOrWhiteSpace(CityTextBox.Text) ? "双流区" : CityTextBox.Text.Trim();

    private async void RefreshWeatherButton_Click(object sender, RoutedEventArgs e) => await RefreshWeatherAsync();

    private async Task RefreshWeatherAsync()
    {
        if (_weatherLoading) return;
        _weatherLoading = true;
        WeatherStatusText.Text = "正在获取实时天气…";
        try
        {
            var location = await ResolveWeatherLocationAsync(GetCity());
            var url = "https://api.open-meteo.com/v1/forecast" +
                      $"?latitude={location.Latitude.ToString(CultureInfo.InvariantCulture)}" +
                      $"&longitude={location.Longitude.ToString(CultureInfo.InvariantCulture)}" +
                      "&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m" +
                      "&hourly=temperature_2m,weather_code" +
                      "&daily=weather_code,temperature_2m_max,temperature_2m_min" +
                      "&timezone=Asia%2FShanghai&forecast_days=2";
            var json = await WeatherHttpClient.GetStringAsync(url);
            using var document = JsonDocument.Parse(json);
            var root = document.RootElement;
            var current = root.GetProperty("current");
            var daily = root.GetProperty("daily");
            var isDay = current.GetProperty("is_day").GetInt32() == 1;
            var weatherCode = current.GetProperty("weather_code").GetInt32();
            var temperature = current.GetProperty("temperature_2m").GetDouble();
            var apparent = current.GetProperty("apparent_temperature").GetDouble();
            var humidity = current.GetProperty("relative_humidity_2m").GetInt32();
            var wind = current.GetProperty("wind_speed_10m").GetDouble();
            var high = daily.GetProperty("temperature_2m_max")[0].GetDouble();
            var low = daily.GetProperty("temperature_2m_min")[0].GetDouble();

            WeatherIconText.Text = GetWeatherIcon(weatherCode, isDay);
            WeatherTemperatureText.Text = $"{Math.Round(temperature):0}°";
            WeatherConditionText.Text = GetWeatherDescription(weatherCode);
            WeatherHighLowText.Text = $"最高 {Math.Round(high):0}°\n最低 {Math.Round(low):0}°";
            WeatherFeelsLikeText.Text = $"{Math.Round(apparent):0}°";
            WeatherHumidityText.Text = $"{humidity}%";
            WeatherWindText.Text = $"{Math.Round(wind):0} km/h";
            PopulateHourlyForecast(root.GetProperty("hourly"));
            WeatherStatusText.Text = $"实时天气 · {location.DisplayName} · 更新于 {DateTime.Now:HH:mm}";
        }
        catch (Exception ex)
        {
            WeatherIconText.Text = "☁";
            WeatherTemperatureText.Text = "--°";
            WeatherConditionText.Text = "暂时无法获取天气";
            WeatherHighLowText.Text = "最高 --°\n最低 --°";
            WeatherFeelsLikeText.Text = "--°";
            WeatherHumidityText.Text = "--%";
            WeatherWindText.Text = "-- km/h";
            WeatherHourlyPanel.Children.Clear();
            WeatherStatusText.Text = "请检查网络后重试";
            SetStatus("天气获取失败：" + ex.GetType().Name + "。MSN 参考页仍可单独打开。");
        }
        finally
        {
            _weatherLoading = false;
        }
    }

    private async Task<(double Latitude, double Longitude, string DisplayName)> ResolveWeatherLocationAsync(string city)
    {
        if (city.Contains("双流", StringComparison.OrdinalIgnoreCase) ||
            city.Equals("成都", StringComparison.OrdinalIgnoreCase) ||
            city.Equals("成都市", StringComparison.OrdinalIgnoreCase))
        {
            return (30.5649, 103.9972, "双流区");
        }

        var url = "https://geocoding-api.open-meteo.com/v1/search?name=" +
                  Uri.EscapeDataString(city) + "&count=1&language=zh&format=json";
        var json = await WeatherHttpClient.GetStringAsync(url);
        using var document = JsonDocument.Parse(json);
        if (!document.RootElement.TryGetProperty("results", out var results) || results.GetArrayLength() == 0)
            throw new InvalidOperationException("没有找到对应城市");
        var result = results[0];
        var name = result.TryGetProperty("name", out var nameValue) ? nameValue.GetString() ?? city : city;
        var latitude = result.GetProperty("latitude").GetDouble();
        var longitude = result.GetProperty("longitude").GetDouble();
        return (latitude, longitude, name);
    }

    private void PopulateHourlyForecast(JsonElement hourly)
    {
        WeatherHourlyPanel.Children.Clear();
        var times = hourly.GetProperty("time");
        var temperatures = hourly.GetProperty("temperature_2m");
        var codes = hourly.GetProperty("weather_code");
        var now = DateTime.Now;
        var indices = new List<int>();
        for (var i = 0; i < times.GetArrayLength(); i++)
        {
            var value = times[i].GetString();
            if (DateTime.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal, out var time) &&
                time >= now.AddMinutes(-45))
            {
                indices.Add(i);
                if (indices.Count == 4) break;
            }
        }

        foreach (var index in indices)
        {
            var timeText = times[index].GetString() ?? "";
            var hourText = DateTime.TryParse(timeText, CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal, out var time)
                ? time.ToString("HH:mm")
                : "--:--";
            var code = codes[index].GetInt32();
            var card = new Border
            {
                Background = new SolidColorBrush(Color.FromRgb(32, 40, 50)),
                BorderBrush = new SolidColorBrush(Color.FromRgb(48, 59, 72)),
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(5),
                Padding = new Thickness(6, 5, 6, 5),
                Margin = new Thickness(0, 0, 5, 0),
                MinWidth = 58
            };
            var stack = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center };
            stack.Children.Add(new TextBlock { Text = hourText, FontSize = 10, Foreground = new SolidColorBrush(Color.FromRgb(147, 162, 180)), HorizontalAlignment = HorizontalAlignment.Center });
            stack.Children.Add(new TextBlock { Text = GetWeatherIcon(code, true), FontSize = 16, Foreground = new SolidColorBrush(Color.FromRgb(255, 214, 107)), Margin = new Thickness(0, 2, 0, 2), HorizontalAlignment = HorizontalAlignment.Center });
            stack.Children.Add(new TextBlock { Text = $"{Math.Round(temperatures[index].GetDouble()):0}°", FontSize = 12, Foreground = new SolidColorBrush(Color.FromRgb(229, 235, 242)), HorizontalAlignment = HorizontalAlignment.Center });
            card.Child = stack;
            WeatherHourlyPanel.Children.Add(card);
        }
        if (indices.Count == 0)
            WeatherHourlyPanel.Children.Add(new TextBlock { Text = "暂无逐小时预报", FontSize = 10, Foreground = new SolidColorBrush(Color.FromRgb(147, 162, 180)) });
    }

    private static string GetWeatherDescription(int code) => code switch
    {
        0 => "晴朗",
        1 => "大部晴朗",
        2 => "局部多云",
        3 => "阴天",
        45 or 48 => "有雾",
        51 or 53 or 55 => "毛毛雨",
        56 or 57 => "冻毛毛雨",
        61 => "小雨",
        63 => "中雨",
        65 => "大雨",
        66 or 67 => "冻雨",
        71 => "小雪",
        73 => "中雪",
        75 => "大雪",
        77 => "雪粒",
        80 => "阵雨",
        81 => "较强阵雨",
        82 => "强阵雨",
        85 or 86 => "阵雪",
        95 => "雷雨",
        96 or 99 => "雷雨伴冰雹",
        _ => "天气状况未知"
    };

    private static string GetWeatherIcon(int code, bool isDay) => code switch
    {
        0 => isDay ? "☀" : "☾",
        1 or 2 => isDay ? "⛅" : "☁",
        3 or 45 or 48 => "☁",
        51 or 53 or 55 or 56 or 57 or 61 or 63 or 65 or 66 or 67 or 80 or 81 or 82 => "🌧",
        71 or 73 or 75 or 77 or 85 or 86 => "❄",
        95 or 96 or 99 => "⛈",
        _ => "☁"
    };

    private void OpenWeatherSourceButton_Click(object sender, RoutedEventArgs e) => OpenUrlInEdge(DefaultMsnWeatherUrl);

    private void OpenUrlInEdge(string url)
    {
        try
        {
            Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, $"未能打开网页。请检查默认浏览器和网络。\n\n{ex.Message}", "网页打开失败", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }

    private void OpenEdgeSearch(string query)
    {
        var url = "https://www.bing.com/search?q=" + Uri.EscapeDataString(query);
        OpenUrlInEdge(url);
    }

    private void EmbedButton_Click(object sender, RoutedEventArgs e)
    {
        if (_embedController.IsEmbedded)
        {
            if (_embedController.TryDetach(this, out var detachMessage))
            {
                if (_activeRecord is not null)
                {
                    if (!_recoveryStore.TryMarkResolved(_activeRecord, detachMessage, out var archiveError))
                        SetStatus("窗口已脱离，但恢复记录归档未完成：" + archiveError);
                    else
                    {
                        _activeRecord = null;
                        ReleaseEmbedMutex();
                    }
                }
                else ReleaseEmbedMutex();
                SetStatus(detachMessage);
                UpdateRecoveryStateText();
            }
            else
            {
                if (_activeRecord is not null)
                {
                    _activeRecord.Status = "RecoveryPending";
                    _activeRecord.LastMessage = detachMessage;
                    _ = _recoveryStore.TryUpdate(_activeRecord, out _);
                }
                MessageBox.Show(this, detachMessage + "\n\n不要重复尝试嵌入。请打开独立恢复工具，或结束本原型进程；本原型没有修改原生桌面图标。", "脱离嵌入未能确认", MessageBoxButton.OK, MessageBoxImage.Warning);
                SetStatus("脱离嵌入未能确认；恢复记录已尽力保留。");
            }
            return;
        }

        if (App.IsSafeMode)
        {
            MessageBox.Show(this, "安全模式禁止桌面嵌入实验。", "安全模式", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        if (_startupRecoveryBlock)
        {
            MessageBox.Show(this, "检测到无法确认或尚未解决的遗留恢复记录。请先打开独立恢复工具；不会覆盖旧记录。", "接管已阻止", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        ShellProbeReport report;
        string diagnosticPath;
        try
        {
            report = ShellDiagnostics.Capture();
            diagnosticPath = ShellDiagnostics.SaveDiagnosticReport(report);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, $"无法保存诊断证据，已禁止嵌入。\n{ex.Message}", "诊断保存失败", MessageBoxButton.OK, MessageBoxImage.Error);
            return;
        }

        if (!ShellDiagnostics.TryGetStableCandidateState(report, out var candidateState, out var reason))
        {
            SetStatus("严格停止：" + reason);
            MessageBox.Show(this, reason + "\n\n诊断报告已保存：\n" + diagnosticPath + "\n\n本次没有修改图标状态，也没有开始嵌入。", "原始状态无法确认", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        var actualConfirm = MessageBox.Show(this,
            $"只读诊断信号显示桌面图标状态为：{(candidateState == "Visible" ? "显示" : "隐藏")}。\n请确认你在实际桌面看到的状态与此一致。\n\n此实验会尝试使用 Explorer 的 WorkerW 窗口结构与未公开消息进行深度嵌入；不同 Windows 版本可能表现不同。\n\n本原型不会隐藏或修改原生图标，也不会自动切换为覆盖层。实验可能造成窗口位置异常；独立恢复工具可结束本原型进程。\n\n是否继续？",
            "确认深度嵌入实验", MessageBoxButton.YesNo, MessageBoxImage.Warning);
        if (actualConfirm != MessageBoxResult.Yes) return;

        if (!TryAcquireEmbedMutex(out var mutexError))
        {
            MessageBox.Show(this, mutexError ?? "同一会话已有另一个状态控制者。", "嵌入实验已阻止", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        var currentProcess = Process.GetCurrentProcess();
        var record = new RecoveryRecord
        {
            Status = "Prepared",
            UserSid = RecoveryRecordStore.CurrentUserSid(),
            SessionId = currentProcess.SessionId,
            ProcessId = currentProcess.Id,
            ProcessStartUtc = new DateTimeOffset(currentProcess.StartTime.ToUniversalTime()),
            ExecutablePath = Environment.ProcessPath ?? "",
            OriginalIconStateCandidate = candidateState,
            UserConfirmedCandidateState = true,
            OriginalHideIconsRaw = report.RegistrySignal.RawValue,
            OriginalSysListViewVisible = report.Windows.FirstOrDefault(w => w.ClassName == "SysListView32")?.IsVisible,
            OriginalDefViewVisible = report.Windows.FirstOrDefault(w => w.ClassName == "SHELLDLL_DefView")?.IsVisible,
            NativeIconStateChanged = false,
            LastMessage = "恢复记录已保存；准备开始深度嵌入实验。此原型不会修改原生图标。"
        };

        if (!_recoveryStore.TryCreate(record, out var saveError))
        {
            ReleaseEmbedMutex();
            MessageBox.Show(this, saveError ?? "恢复记录无法可靠保存，已禁止嵌入。", "恢复记录保存失败", MessageBoxButton.OK, MessageBoxImage.Error);
            return;
        }
        _activeRecord = record;

        if (!_embedController.TryEmbed(this, out var embedMessage))
        {
            if (!_recoveryStore.TryMarkResolved(record, embedMessage, out var archiveError))
                SetStatus("嵌入未成功；恢复记录归档仍待处理：" + archiveError);
            else
            {
                _activeRecord = null;
                ReleaseEmbedMutex();
            }
            MessageBox.Show(this, embedMessage, "深度嵌入未通过", MessageBoxButton.OK, MessageBoxImage.Warning);
            SetStatus("深度嵌入未通过；没有切换为覆盖层，原生图标未修改。");
            UpdateRecoveryStateText();
            return;
        }

        record.Status = "Embedded";
        record.EmbedTargetHandle = $"0x{_embedController.TargetHandle.ToInt64():X}";
        record.LastMessage = embedMessage;
        if (!_recoveryStore.TryUpdate(record, out var updateError))
        {
            var detached = _embedController.TryDetach(this, out var rollbackMessage);
            if (detached)
            {
                _ = _recoveryStore.TryMarkResolved(record, "嵌入记录更新失败，已尝试脱离：" + rollbackMessage, out _);
                _activeRecord = null;
                ReleaseEmbedMutex();
            }
            else
            {
                record.Status = "RecoveryPending";
                record.LastMessage = "嵌入记录更新失败，且自动脱离未能确认。" + updateError + " " + rollbackMessage;
                _ = _recoveryStore.TryUpdate(record, out _);
            }
            MessageBox.Show(this, "嵌入后无法可靠更新恢复记录，已尝试立即脱离。\n" + updateError + "\n" + rollbackMessage, "恢复记录异常", MessageBoxButton.OK, MessageBoxImage.Error);
            UpdateRecoveryStateText();
            return;
        }

        EmbedButton.Content = "退出嵌入实验";
        SetStatus(embedMessage);
        UpdateRecoveryStateText();
    }

    private void RecoveryButton_Click(object sender, RoutedEventArgs e)
    {
        var recoveryExe = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "Recovery", "DesktopOrganizer.Recovery.exe"));
        if (!File.Exists(recoveryExe))
        {
            MessageBox.Show(this, "没有找到独立恢复工具。请先在项目根目录运行 build.ps1，生成 dist\\Recovery\\DesktopOrganizer.Recovery.exe。\n\n恢复记录目录：\n" + AppDataPaths.RecoveryDirectory, "恢复工具尚未发布", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        try { Process.Start(new ProcessStartInfo(recoveryExe) { UseShellExecute = true }); }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "无法启动恢复工具", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    private void SafeModeButton_Click(object sender, RoutedEventArgs e)
    {
        if (_embedController.IsEmbedded)
        {
            if (!_embedController.TryDetach(this, out var detachMessage))
            {
                MessageBox.Show(this, "无法确认已脱离嵌入，因此不会启动第二个实例。\n" + detachMessage, "安全启动已阻止", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (_activeRecord is not null)
            {
                if (_recoveryStore.TryMarkResolved(_activeRecord, "进入安全模式前已成功脱离嵌入。", out _))
                {
                    _activeRecord = null;
                    ReleaseEmbedMutex();
                }
            }
            EmbedButton.Content = "深度嵌入实验";
            UpdateRecoveryStateText();
        }
        try
        {
            var exe = Environment.ProcessPath;
            if (string.IsNullOrWhiteSpace(exe)) throw new InvalidOperationException("无法确定当前程序路径。");
            Process.Start(new ProcessStartInfo(exe, "--safe-mode") { UseShellExecute = true });
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "安全启动失败", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    private void Window_Closing(object? sender, CancelEventArgs e)
    {
        FinishDividerDrag(cancel: false);
        _clockTimer.Stop();
        if (_embedController.IsEmbedded)
        {
            if (_embedController.TryDetach(this, out var message))
            {
                if (_activeRecord is not null)
                {
                    if (!_recoveryStore.TryMarkResolved(_activeRecord, "正常退出：" + message, out var archiveError))
                        MessageBox.Show(this, "窗口已脱离，但恢复记录归档未完成。请保留记录并在下次启动前检查恢复工具。\n" + archiveError, "恢复记录待处理", MessageBoxButton.OK, MessageBoxImage.Warning);
                    else _activeRecord = null;
                }
            }
            else
            {
                if (_activeRecord is not null)
                {
                    _activeRecord.Status = "RecoveryPending";
                    _activeRecord.LastMessage = message;
                    _ = _recoveryStore.TryUpdate(_activeRecord, out _);
                }
                MessageBox.Show(this, "未能确认窗口已脱离。关闭本程序会销毁其窗口；如果仍有异常，请运行独立恢复工具并停止本原型进程。原生桌面图标没有被本原型修改。\n\n" + message, "退出前恢复提示", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
        else if (_activeRecord is not null && string.Equals(_activeRecord.Status, "Prepared", StringComparison.Ordinal))
        {
            _ = _recoveryStore.TryMarkResolved(_activeRecord, "嵌入尚未开始，主程序正常退出。", out _);
        }
        ReleaseEmbedMutex();
        SaveLayout();
    }

    private bool TryAcquireEmbedMutex(out string? error)
    {
        error = null;
        try
        {
            var currentSid = RecoveryRecordStore.CurrentUserSid();
            if (string.IsNullOrWhiteSpace(currentSid) || currentSid == "unknown")
            {
                error = "无法可靠确认当前用户 SID，已禁止桌面接管。";
                return false;
            }
            var sid = currentSid.Replace('-', '_');
            var session = Process.GetCurrentProcess().SessionId;
            _embedMutex = new Mutex(initiallyOwned: false, name: $@"Local\DesktopOrganizer_EmbedControl_{sid}_S{session}");
            try { _ownsEmbedMutex = _embedMutex.WaitOne(0); }
            catch (AbandonedMutexException) { _ownsEmbedMutex = true; }
            if (_ownsEmbedMutex) return true;
            _embedMutex.Dispose();
            _embedMutex = null;
            error = "同一登录会话已经有另一个桌面状态控制者。请先处理现有实例和恢复记录。";
            return false;
        }
        catch (Exception ex)
        {
            error = "无法建立单实例控制锁，已禁止嵌入：" + ex.Message;
            ReleaseEmbedMutex();
            return false;
        }
    }

    private void ReleaseEmbedMutex()
    {
        try { if (_ownsEmbedMutex) _embedMutex?.ReleaseMutex(); } catch { }
        try { _embedMutex?.Dispose(); } catch { }
        _embedMutex = null;
        _ownsEmbedMutex = false;
    }

    private void SaveLayout()
    {
        if (_isLoadingLayout || _layout is null) return;
        if (_dividerError is not null) { SetStatus(_dividerError + " 自动保存已暂停，以保留原布局数据。"); return; }
        if (_layoutLoadFailed)
        {
            SetStatus("原布局文件读取失败，为保护原文件，本次自动保存已暂停。请先备份并手动处理损坏的布局文件。");
            return;
        }
        try
        {
            if (_draggingDivider is not null) return; // Do not persist an uncommitted gesture via unrelated UI events.
            CaptureDividerState();
            _layout.Shortcuts = _shortcuts.ToList();
            _layout.FileReferences = _fileReferences.ToList();
            _layout.Todos = _todos.ToList();
            _layout.NeonEnabled = NeonBar.Visibility == Visibility.Visible;
            _layout.NeonLengthPercent = Math.Clamp(_layout.NeonLengthPercent, 20, 100);
            _layout.NeonThickness = Math.Clamp(_layout.NeonThickness, 2, 20);
            _layout.City = CityTextBox.Text.Trim();
            _layout.RegionTitles ??= new Dictionary<string, string>();
            _layout.TitlePositions ??= new Dictionary<string, TitlePosition>();
            var appTitleX = Canvas.GetLeft(ApplicationsTitle);
            var appTitleY = Canvas.GetTop(ApplicationsTitle);
            _layout.ApplicationsTitleX = double.IsFinite(appTitleX) ? appTitleX : 0;
            _layout.ApplicationsTitleY = double.IsFinite(appTitleY) ? appTitleY : 0;
            _layout.RegionSplits = _regionRoots;
            LayoutStore.Save(_layout);
        }
        catch (Exception ex)
        {
            SetStatus("布局自动保存失败：" + ex.Message + "。原有布局文件已尽可能保留。");
        }
    }

    private void UpdateClock()
    {
        ClockText.Text = DateTime.Now.ToString("HH:mm:ss");
        DateText.Text = DateTime.Now.ToString("yyyy年M月d日 dddd");
    }

    private void UpdateRecoveryStateText()
    {
        if (_activeRecord is not null)
            RecoveryStateText.Text = "恢复记录：" + _activeRecord.Status;
        else if (_startupRecoveryBlock)
            RecoveryStateText.Text = "恢复记录：需人工检查";
        else
            RecoveryStateText.Text = "恢复记录：无未解决记录";
        EmbedButton.IsEnabled = !_startupRecoveryBlock || _embedController.IsEmbedded;
        if (App.IsSafeMode && !_embedController.IsEmbedded) EmbedButton.IsEnabled = false;
    }

    private void SetStatus(string message) => StatusText.Text = message;
}
