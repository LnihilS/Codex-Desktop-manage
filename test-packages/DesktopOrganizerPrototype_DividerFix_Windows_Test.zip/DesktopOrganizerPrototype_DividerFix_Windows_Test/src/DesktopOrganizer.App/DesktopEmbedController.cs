using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Interop;

namespace DesktopOrganizer.App;

/// <summary>
/// Experimental P0 proof only. It does not hide or change native desktop icons.
/// The WorkerW/0x052C behavior is undocumented and must be treated as version-dependent.
/// </summary>
internal sealed class DesktopEmbedController
{
    private const int GWL_STYLE = -16;
    private const long WS_CHILD = 0x40000000L;
    private const long WS_POPUP = unchecked((long)0x80000000);
    private const long WS_CAPTION = 0x00C00000L;
    private const long WS_THICKFRAME = 0x00040000L;
    private const long WS_SYSMENU = 0x00080000L;
    private const long WS_MINIMIZEBOX = 0x00020000L;
    private const long WS_MAXIMIZEBOX = 0x00010000L;
    private const uint SWP_FRAMECHANGED = 0x0020;
    private const uint SWP_SHOWWINDOW = 0x0040;
    private const uint SWP_NOZORDER = 0x0004;
    private const uint SMTO_ABORTIFHUNG = 0x0002;
    private const uint WM_SPAWN_WORKER = 0x052C;
    private const uint GW_CHILD = 5;
    private const uint GW_HWNDNEXT = 2;

    private nint _hwnd;
    private nint _target;
    private nint _originalStyle;
    private RECT _originalRect;
    private bool _embedded;

    public bool IsEmbedded => _embedded;
    public nint TargetHandle => _target;

    public bool TryEmbed(Window window, out string message)
    {
        message = "";
        if (!OperatingSystem.IsWindows())
        {
            message = "深度嵌入实验仅支持 Windows。";
            return false;
        }
        if (_embedded)
        {
            message = "窗口已经处于嵌入状态。";
            return true;
        }

        _hwnd = new WindowInteropHelper(window).Handle;
        if (_hwnd == nint.Zero)
        {
            message = "无法取得主窗口句柄；未执行嵌入。";
            return false;
        }
        if (!GetWindowRect(_hwnd, out _originalRect))
        {
            message = "无法读取原窗口位置；未执行嵌入。";
            return false;
        }
        _originalStyle = GetWindowLongPtrSafe(_hwnd, GWL_STYLE);

        var progman = FindWindow("Progman", null);
        if (progman == nint.Zero)
        {
            message = "未找到 Progman 桌面窗口；未执行嵌入。";
            return false;
        }

        // This message is undocumented. It is only sent after the user explicitly confirms the experiment.
        _ = SendMessageTimeout(progman, WM_SPAWN_WORKER, new nint(0xD), new nint(1), SMTO_ABORTIFHUNG, 1000, out _);
        Thread.Sleep(250);

        if (!TryFindVisibleWorkerW(progman, out _target, out var findReason))
        {
            message = findReason + "未更改图标状态，也未切换为覆盖层。";
            _target = nint.Zero;
            return false;
        }

        try
        {
            var style = _originalStyle.ToInt64();
            var childStyle = (style & ~(WS_POPUP | WS_CAPTION | WS_THICKFRAME | WS_SYSMENU | WS_MINIMIZEBOX | WS_MAXIMIZEBOX)) | WS_CHILD;
            SetWindowLongPtrChecked(_hwnd, GWL_STYLE, new nint(childStyle));

            Marshal.SetLastPInvokeError(0);
            var previousParent = SetParent(_hwnd, _target);
            var parentError = Marshal.GetLastPInvokeError();
            if (previousParent == nint.Zero && parentError != 0)
                throw new InvalidOperationException($"SetParent 失败，Win32 错误码 {parentError}。 ");

            if (!GetClientRect(_target, out var client) || client.Right - client.Left < 200 || client.Bottom - client.Top < 200)
                throw new InvalidOperationException("目标 WorkerW 的客户区无效或尺寸过小。");

            if (!SetWindowPos(_hwnd, nint.Zero, 0, 0, client.Right - client.Left, client.Bottom - client.Top,
                    SWP_FRAMECHANGED | SWP_SHOWWINDOW | SWP_NOZORDER))
                throw new InvalidOperationException($"SetWindowPos 失败，Win32 错误码 {Marshal.GetLastPInvokeError()}。");

            _embedded = true;
            message = $"实验性嵌入调用成功，目标 WorkerW={FormatHandle(_target)}。原生桌面图标没有被隐藏或修改。请检查实际画面、Win+D、任务栏和输入交互。";
            return true;
        }
        catch (Exception ex)
        {
            var rollbackOk = TryRestoreWindow(window, out var rollbackMessage);
            _target = nint.Zero;
            message = $"深度嵌入失败：{ex.Message}。{(rollbackOk ? "窗口已尝试恢复为普通窗口。" : "窗口自动回退未能确认：" + rollbackMessage)} 未切换为覆盖层。";
            return false;
        }
    }

    public bool TryDetach(Window window, out string message)
    {
        if (!_embedded)
        {
            message = "当前没有活动的嵌入窗口。";
            return true;
        }
        var ok = TryRestoreWindow(window, out message);
        if (ok)
        {
            _embedded = false;
            _target = nint.Zero;
            message = "已将窗口恢复为普通窗口；原生桌面图标没有被修改。";
        }
        return ok;
    }

    private bool TryRestoreWindow(Window window, out string message)
    {
        message = "";
        if (_hwnd == nint.Zero || !IsWindow(_hwnd))
        {
            message = "主窗口句柄已失效。进程退出后窗口应随之销毁；请使用独立恢复工具检查遗留记录。";
            return false;
        }

        try
        {
            Marshal.SetLastPInvokeError(0);
            var previous = SetParent(_hwnd, nint.Zero);
            var parentError = Marshal.GetLastPInvokeError();
            if (previous == nint.Zero && parentError != 0)
                throw new InvalidOperationException($"SetParent 回退失败，Win32 错误码 {parentError}。");

            SetWindowLongPtrChecked(_hwnd, GWL_STYLE, _originalStyle);
            var width = Math.Max(400, _originalRect.Right - _originalRect.Left);
            var height = Math.Max(300, _originalRect.Bottom - _originalRect.Top);
            if (!SetWindowPos(_hwnd, nint.Zero, _originalRect.Left, _originalRect.Top, width, height,
                    SWP_FRAMECHANGED | SWP_SHOWWINDOW | SWP_NOZORDER))
                throw new InvalidOperationException($"恢复窗口位置失败，Win32 错误码 {Marshal.GetLastPInvokeError()}。");

            window.WindowState = WindowState.Normal;
            message = "普通窗口已恢复。";
            return true;
        }
        catch (Exception ex)
        {
            message = ex.Message;
            return false;
        }
    }

    private static bool TryFindVisibleWorkerW(nint progman, out nint target, out string reason)
    {
        target = nint.Zero;
        reason = "未找到与桌面 Progman 同进程、可见且可验证的 WorkerW 宿主。";
        _ = GetWindowThreadProcessId(progman, out var progmanPid);
        nint defViewTop = nint.Zero;

        EnumWindows((top, _) =>
        {
            if (FindWindowEx(top, nint.Zero, "SHELLDLL_DefView", null) != nint.Zero)
            {
                defViewTop = top;
                return false;
            }
            return true;
        }, nint.Zero);

        if (defViewTop != nint.Zero)
        {
            var sibling = FindWindowEx(nint.Zero, defViewTop, "WorkerW", null);
            if (IsValidHost(sibling, progmanPid))
            {
                target = sibling;
                return true;
            }
        }

        // Search only within the same Explorer process; do not fall back to Progman or an overlay.
        nint foundTarget = nint.Zero;
        EnumWindows((top, _) =>
        {
            if (GetClassNameSafe(top) == "WorkerW" && IsValidHost(top, progmanPid))
            {
                foundTarget = top;
                return false;
            }
            return true;
        }, nint.Zero);

        if (foundTarget != nint.Zero)
        {
            target = foundTarget;
            return true;
        }
        reason = "没有找到可见且可验证的 WorkerW 宿主。该系统上的深度嵌入条件尚不成立；没有执行嵌入，也不会自动改用覆盖层。";
        return false;
    }

    private static bool IsValidHost(nint hwnd, uint progmanPid)
    {
        if (hwnd == nint.Zero || !IsWindow(hwnd) || !IsWindowVisible(hwnd) || GetClassNameSafe(hwnd) != "WorkerW") return false;
        _ = GetWindowThreadProcessId(hwnd, out var pid);
        return pid == progmanPid;
    }

    private static string GetClassNameSafe(nint hwnd)
    {
        var sb = new StringBuilder(256);
        return GetClassName(hwnd, sb, sb.Capacity) > 0 ? sb.ToString() : "";
    }

    private static string FormatHandle(nint handle) => $"0x{handle.ToInt64():X}";

    private static nint GetWindowLongPtrSafe(nint hwnd, int index) =>
        IntPtr.Size == 8 ? GetWindowLongPtr64(hwnd, index) : new nint(GetWindowLong32(hwnd, index));

    private static void SetWindowLongPtrChecked(nint hwnd, int index, nint value)
    {
        Marshal.SetLastPInvokeError(0);
        var previous = IntPtr.Size == 8 ? SetWindowLongPtr64(hwnd, index, value) : new nint(SetWindowLong32(hwnd, index, value.ToInt32()));
        var error = Marshal.GetLastPInvokeError();
        if (previous == nint.Zero && error != 0) throw new InvalidOperationException($"SetWindowLongPtr 失败，Win32 错误码 {error}。");
    }

    [StructLayout(LayoutKind.Sequential)] private struct RECT { public int Left; public int Top; public int Right; public int Bottom; }
    [StructLayout(LayoutKind.Sequential)] private struct POINT { public int X; public int Y; }
    private delegate bool EnumWindowsProc(nint hwnd, nint lParam);

    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern nint FindWindow(string? className, string? windowName);
    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern nint FindWindowEx(nint parent, nint childAfter, string? className, string? windowName);
    [DllImport("user32.dll", SetLastError = true)] private static extern bool EnumWindows(EnumWindowsProc callback, nint lParam);
    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern int GetClassName(nint hwnd, StringBuilder className, int maxCount);
    [DllImport("user32.dll", SetLastError = true)] private static extern uint GetWindowThreadProcessId(nint hwnd, out uint processId);
    [DllImport("user32.dll")] [return: MarshalAs(UnmanagedType.Bool)] private static extern bool IsWindow(nint hwnd);
    [DllImport("user32.dll")] [return: MarshalAs(UnmanagedType.Bool)] private static extern bool IsWindowVisible(nint hwnd);
    [DllImport("user32.dll", SetLastError = true)] private static extern bool GetWindowRect(nint hwnd, out RECT rect);
    [DllImport("user32.dll", SetLastError = true)] private static extern bool GetClientRect(nint hwnd, out RECT rect);
    [DllImport("user32.dll", SetLastError = true)] private static extern nint SetParent(nint child, nint newParent);
    [DllImport("user32.dll", EntryPoint = "SetWindowLongPtrW", SetLastError = true)] private static extern nint SetWindowLongPtr64(nint hwnd, int index, nint value);
    [DllImport("user32.dll", EntryPoint = "GetWindowLongPtrW", SetLastError = true)] private static extern nint GetWindowLongPtr64(nint hwnd, int index);
    [DllImport("user32.dll", EntryPoint = "SetWindowLongW", SetLastError = true)] private static extern int SetWindowLong32(nint hwnd, int index, int value);
    [DllImport("user32.dll", EntryPoint = "GetWindowLongW", SetLastError = true)] private static extern int GetWindowLong32(nint hwnd, int index);
    [DllImport("user32.dll", SetLastError = true)] private static extern bool SetWindowPos(nint hwnd, nint insertAfter, int x, int y, int cx, int cy, uint flags);
    [DllImport("user32.dll", SetLastError = true)] private static extern nint SendMessageTimeout(nint hwnd, uint msg, nint wParam, nint lParam, uint flags, uint timeout, out nint result);
}
