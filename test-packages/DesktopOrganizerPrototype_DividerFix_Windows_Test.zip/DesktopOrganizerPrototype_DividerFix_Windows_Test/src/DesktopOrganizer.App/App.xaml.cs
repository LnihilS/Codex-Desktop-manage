using System.Windows;

namespace DesktopOrganizer.App;

public partial class App : Application
{
    public static bool IsSafeMode { get; private set; }

    protected override void OnStartup(StartupEventArgs e)
    {
        IsSafeMode = e.Args.Any(a => string.Equals(a, "--safe-mode", StringComparison.OrdinalIgnoreCase));
        base.OnStartup(e);
    }
}
