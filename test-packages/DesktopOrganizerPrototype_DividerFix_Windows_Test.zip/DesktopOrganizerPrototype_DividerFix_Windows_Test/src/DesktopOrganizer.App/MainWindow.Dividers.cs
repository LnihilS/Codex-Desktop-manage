using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using DesktopOrganizer.Core;

namespace DesktopOrganizer.App;

public partial class MainWindow
{
    private const string MainDividerId = "main:horizontal";
    private const string UpperDividerId = "main:upper-vertical";
    private const string LowerDividerId = "main:lower-vertical";
    private sealed record DividerView(string Id, Grid Host, GridSplitter Splitter, DividerAxis Axis);
    private readonly Dictionary<string, DividerView> _dividerViews = new();
    private readonly List<(Grid Host, Button Button)> _junctionButtons = new();
    private DividerLayout? _dividerLayout;
    private GridSplitter? _draggingDivider;
    private string? _draggingDividerId;
    private Dictionary<string, double>? _dragOriginal;
    private Point _dividerDragStart;
    private double _dividerPositionStart;
    private bool _applyingDividers;
    private string? _dividerError;

    private static string DividerId(RegionSplitNode node) => "region:" + node.Id;

    private void RegisterDivider(string id, Grid host, GridSplitter splitter, DividerAxis axis)
    {
        splitter.Uid = id;
        _dividerViews[id] = new(id, host, splitter, axis);
        // Own the gesture before GridSplitter/Thumb mutates any star definitions.
        // No delayed Dispatcher callback is involved in position updates or saving.
        splitter.PreviewMouseLeftButtonDown += Divider_Down;
        splitter.PreviewMouseMove += Divider_Move;
        splitter.PreviewMouseLeftButtonUp += Divider_Up;
        splitter.LostMouseCapture += Divider_LostCapture;
        splitter.PreviewKeyDown += Divider_KeyDown;
        splitter.ShowsPreview = false;
    }

    private void InitializeDividerController()
    {
        RegisterDivider(MainDividerId, DesktopGrid, HorizontalSplitterMain, DividerAxis.Horizontal);
        RegisterDivider(UpperDividerId, UpperRegionGrid, VerticalSplitterTop, DividerAxis.Vertical);
        RegisterDivider(LowerDividerId, LowerRegionGrid, VerticalSplitterBottom, DividerAxis.Vertical);
        CreateDividerLayout();
        DesktopGrid.SizeChanged += (_, _) => ResizeDividerViewport();
        Loaded += (_, _) => ResizeDividerViewport();
    }

    private void CreateDividerLayout()
    {
        if (_layout is null) return;
        DividerNode BuildRegion(RegionSplitNode node, double minWidth = 70) => new()
        {
            Id = DividerId(node), Ratio = node.Ratio,
            Axis = node.Orientation == "Vertical" ? DividerAxis.Vertical : DividerAxis.Horizontal,
            MinWidth = minWidth, MinHeight = 55,
            First = node.First is null ? null : BuildRegion(node.First),
            Second = node.Second is null ? null : BuildRegion(node.Second)
        };
        double Ratio(double a, double b) => double.IsFinite(a + b) && a + b > 0 ? a / (a + b) : .5;
        var tree = new DividerNode
        {
            Id = MainDividerId, Axis = DividerAxis.Horizontal, MinWidth = 0, MinHeight = 0,
            Ratio = Ratio(_layout.TopRowRatio, _layout.BottomRowRatio),
            First = new()
            {
                Id = UpperDividerId, Axis = DividerAxis.Vertical, MinHeight = 220, MinWidth = 0,
                Ratio = Ratio(_layout.UpperLeftColumnRatio, _layout.UpperRightColumnRatio),
                First = BuildRegion(_regionRoots["ApplicationsRegion"], 320),
                Second = BuildRegion(_regionRoots["TodoRegion"], 245)
            },
            Second = new()
            {
                Id = LowerDividerId, Axis = DividerAxis.Vertical, MinHeight = 170, MinWidth = 0,
                Ratio = Ratio(_layout.LowerLeftColumnRatio, _layout.LowerRightColumnRatio),
                First = BuildRegion(_regionRoots["ReferencesRegion"], 320),
                Second = BuildRegion(_regionRoots["ClockWeatherRegion"], 245)
            }
        };
        try
        {
            _dividerLayout = new(tree, _layout.Dividers ??= new());
            var minimum = _dividerLayout.MinimumSize;
            DesktopGrid.MinWidth = minimum.Width;
            DesktopGrid.MinHeight = minimum.Height;
            _dividerError = null;
            ResizeDividerViewport();
        }
        catch (InvalidDataException ex)
        {
            _dividerError = ex.Message;
            _dividerLayout = null;
            SetStatus(_dividerError);
        }
    }

    private void ResizeDividerViewport()
    {
        if (_applyingDividers || _dividerLayout is null || DesktopGrid.ActualWidth <= 0 || DesktopGrid.ActualHeight <= 0) return;
        if (_draggingDivider is not null) FinishDividerDrag(cancel: true);
        if (!_dividerLayout.Resize(DesktopGrid.ActualWidth, DesktopGrid.ActualHeight, out var message))
        { _dividerError = message; SetStatus(message); return; }
        _dividerError = null;
        ApplyDividerGeometry();
    }

    private void ApplyDividerGeometry()
    {
        if (_dividerLayout is null) return;
        _applyingDividers = true;
        try
        {
            var boxes = _dividerLayout.Boxes;
            foreach (var view in _dividerViews.Values)
            {
                if (!boxes.TryGetValue(view.Id, out var b)) continue;
                var p = _dividerLayout.State.Positions[view.Id];
                if (view.Axis == DividerAxis.Vertical)
                {
                    SetWidth(view.Host.ColumnDefinitions[0], p - DividerLayout.Thickness / 2 - b.X);
                    SetWidth(view.Host.ColumnDefinitions[2], b.X + b.Width - p - DividerLayout.Thickness / 2);
                }
                else
                {
                    SetHeight(view.Host.RowDefinitions[0], p - DividerLayout.Thickness / 2 - b.Y);
                    SetHeight(view.Host.RowDefinitions[2], b.Y + b.Height - p - DividerLayout.Thickness / 2);
                }
            }
            DesktopGrid.UpdateLayout(); // Synchronous: final geometry exists before saving or inspecting joints.
            RefreshDividerJunctions();
        }
        finally { _applyingDividers = false; }
    }

    private static void SetWidth(ColumnDefinition d, double value)
    {
        if (!d.Width.IsAbsolute || Math.Abs(d.Width.Value - value) > .00001) d.Width = new(Math.Max(0, value));
    }
    private static void SetHeight(RowDefinition d, double value)
    {
        if (!d.Height.IsAbsolute || Math.Abs(d.Height.Value - value) > .00001) d.Height = new(Math.Max(0, value));
    }

    private void Divider_Down(object sender, MouseButtonEventArgs e)
    {
        e.Handled = true;
        if (!_isEditing || _dividerLayout is null || _dividerError is not null || sender is not GridSplitter splitter) return;
        _draggingDivider = splitter; _draggingDividerId = splitter.Uid;
        _dragOriginal = new(_dividerLayout.State.Positions);
        _dividerDragStart = e.GetPosition(DesktopGrid);
        _dividerPositionStart = _dividerLayout.State.Positions[splitter.Uid];
        splitter.Focus();
        if (!splitter.CaptureMouse()) FinishDividerDrag(cancel: true);
    }

    private void Divider_Move(object sender, MouseEventArgs e)
    {
        if (_draggingDivider is null || _draggingDividerId is null || _dividerLayout is null) return;
        e.Handled = true;
        var point = e.GetPosition(DesktopGrid);
        var view = _dividerViews[_draggingDividerId];
        var delta = view.Axis == DividerAxis.Vertical ? point.X - _dividerDragStart.X : point.Y - _dividerDragStart.Y;
        _dividerLayout.Move(view.Id, _dividerPositionStart + delta, out var message);
        ApplyDividerGeometry();
        if (message.Length > 0) SetStatus(message);
        if (e.LeftButton != MouseButtonState.Pressed) FinishDividerDrag(cancel: false);
    }

    private void Divider_Up(object sender, MouseButtonEventArgs e)
    {
        e.Handled = true;
        if (_draggingDivider is null) return;
        Divider_Move(sender, e);
        FinishDividerDrag(cancel: false);
    }

    private void Divider_LostCapture(object sender, MouseEventArgs e)
    {
        if (ReferenceEquals(sender, _draggingDivider)) FinishDividerDrag(cancel: true);
    }

    private void FinishDividerDrag(bool cancel)
    {
        var splitter = _draggingDivider;
        if (splitter is null || _dividerLayout is null) return;
        _draggingDivider = null; _draggingDividerId = null;
        if (cancel && _dragOriginal is not null) _dividerLayout.State.Positions = _dragOriginal;
        _dragOriginal = null;
        splitter.ReleaseMouseCapture();
        ApplyDividerGeometry();
        SaveLayout();
        if (cancel) SetStatus("已取消本次拖动，分割线恢复到拖动前位置。");
    }

    private void Divider_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Escape && _draggingDivider is not null)
        { e.Handled = true; FinishDividerDrag(cancel: true); return; }
        if (!_isEditing || _dividerLayout is null || _dividerError is not null || sender is not GridSplitter s) return;
        var axis = _dividerViews[s.Uid].Axis;
        var delta = axis == DividerAxis.Vertical ? e.Key == Key.Left ? -1 : e.Key == Key.Right ? 1 : 0
            : e.Key == Key.Up ? -1 : e.Key == Key.Down ? 1 : 0;
        if (delta == 0) { e.Handled = e.Key != Key.Tab; return; } // Prevent GridSplitter's built-in keyboard resize.
        e.Handled = true;
        _dividerLayout.Move(s.Uid, _dividerLayout.State.Positions[s.Uid] + delta * (Keyboard.Modifiers.HasFlag(ModifierKeys.Shift) ? 10 : 1), out var message);
        ApplyDividerGeometry(); SaveLayout();
        if (message.Length > 0) SetStatus(message);
    }

    private void RefreshDividerJunctions()
    {
        foreach (var (host, button) in _junctionButtons) host.Children.Remove(button);
        _junctionButtons.Clear();
        if (_dividerLayout is null || _dividerError is not null) return;
        var boxes = _dividerLayout.Boxes;
        var segments = _dividerLayout.Segments();
        foreach (var joint in _dividerLayout.Junctions())
        {
            if (!_isEditing && !joint.Linked) continue;
            var line = _dividerViews[joint.FirstId];
            var cross = segments.FirstOrDefault(s => s.Axis != line.Axis
                && Math.Abs(s.Position - (s.Axis == DividerAxis.Horizontal ? joint.Y : joint.X)) < .01
                && (s.Axis == DividerAxis.Horizontal ? joint.X : joint.Y) >= s.Start
                && (s.Axis == DividerAxis.Horizontal ? joint.X : joint.Y) <= s.End);
            if (cross is null || !_dividerViews.TryGetValue(cross.Id, out var separator)) continue;
            var box = boxes[cross.Id];
            // A real junction control occupies only the existing 5px perpendicular separator cell.
            // It is not a window overlay or a line drawn over incorrectly aligned regions.
            var button = new Button
            {
                Width = 5, Height = 5, Padding = new Thickness(0), BorderThickness = new Thickness(0),
                Background = _isEditing ? Brushes.LightCyan : line.Splitter.Background,
                HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Top,
                Focusable = false, IsHitTestVisible = _isEditing,
                Opacity = _isEditing ? 1 : line.Splitter.Opacity,
                ToolTip = joint.Linked ? "已合并：右键此亮点取消这两段线的合并" : "可合并：右键此亮点合并这两段线",
                Margin = new Thickness(cross.Axis == DividerAxis.Horizontal ? joint.X - box.X - 2.5 : 0,
                    cross.Axis == DividerAxis.Vertical ? joint.Y - box.Y - 2.5 : 0, 0, 0)
            };
            // Bypass application-wide button templates so the five-pixel junction has no padding/chrome.
            var template = new ControlTemplate(typeof(Button));
            var border = new FrameworkElementFactory(typeof(Border));
            border.SetValue(Border.BackgroundProperty, button.Background);
            template.VisualTree = border; button.Template = template;
            Grid.SetColumn(button, cross.Axis == DividerAxis.Vertical ? 1 : 0);
            Grid.SetRow(button, cross.Axis == DividerAxis.Horizontal ? 1 : 0);
            Panel.SetZIndex(button, 1);
            var menu = new ContextMenu();
            var action = new MenuItem { Header = joint.Linked ? "取消合并这两段分割线" : "合并这两段分割线" };
            action.Click += (_, _) => ChangeDividerLink(joint);
            menu.Items.Add(action); button.ContextMenu = menu;
            separator.Host.Children.Add(button); _junctionButtons.Add((separator.Host, button));
        }
    }

    private void ChangeDividerLink(DividerJunction joint)
    {
        if (!_isEditing || _dividerLayout is null || _dividerError is not null) return;
        string message;
        if (joint.Linked)
        {
            if (!_dividerLayout.Unmerge(joint.FirstId, joint.SecondId)) return;
            message = "已取消这两段线的合并；当前位置保留，可以分别拖动。";
        }
        else if (!_dividerLayout.Merge(joint.FirstId, joint.SecondId, out message))
        {
            SetStatus(message);
            MessageBox.Show(this, message, "无法合并分割线", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        ApplyDividerGeometry(); SaveLayout(); SetStatus(message);
    }

    // Keep legacy ratio fields readable for old versions, derived from the SAME committed geometry.
    private void CaptureDividerState()
    {
        if (_layout is null || _dividerLayout is null || _dividerError is not null || _dividerLayout.State.Positions.Count == 0) return;
        DesktopGrid.UpdateLayout();
        foreach (var view in _dividerViews.Values)
        {
            var origin = view.Splitter.TranslatePoint(new Point(0, 0), DesktopGrid);
            var actual = view.Axis == DividerAxis.Vertical ? origin.X + view.Splitter.ActualWidth / 2
                : origin.Y + view.Splitter.ActualHeight / 2;
            if (Math.Abs(actual - _dividerLayout.State.Positions[view.Id]) > .05)
                throw new InvalidOperationException($"分割线 {view.Id} 的屏幕位置与模型不一致，已停止保存，请保留布局文件并检查窗口尺寸。");
        }
        _layout.Dividers = _dividerLayout.State;
        var boxes = _dividerLayout.Boxes;
        double Ratio(string id, DividerAxis axis)
        {
            var b = boxes[id]; var p = _dividerLayout.State.Positions[id];
            return axis == DividerAxis.Vertical ? (p - b.X - 2.5) / (b.Width - 5) : (p - b.Y - 2.5) / (b.Height - 5);
        }
        _layout.TopRowRatio = Ratio(MainDividerId, DividerAxis.Horizontal); _layout.BottomRowRatio = 1 - _layout.TopRowRatio;
        _layout.UpperLeftColumnRatio = Ratio(UpperDividerId, DividerAxis.Vertical); _layout.UpperRightColumnRatio = 1 - _layout.UpperLeftColumnRatio;
        _layout.LowerLeftColumnRatio = Ratio(LowerDividerId, DividerAxis.Vertical); _layout.LowerRightColumnRatio = 1 - _layout.LowerLeftColumnRatio;
        _layout.LeftColumnRatio = _layout.UpperLeftColumnRatio; _layout.RightColumnRatio = _layout.UpperRightColumnRatio;
        foreach (var view in _dividerViews.Values)
            if (view.Host.Tag is RegionSplitNode node) node.Ratio = Ratio(view.Id, view.Axis);
    }
}
