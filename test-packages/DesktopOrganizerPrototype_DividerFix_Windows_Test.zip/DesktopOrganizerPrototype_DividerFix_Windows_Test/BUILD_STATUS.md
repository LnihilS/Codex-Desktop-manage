# Build status — V0.4 background and readability update

- Based on the previously published V0.3 source package.
- Fixes the font-size category ComboBox popup styling with dark item backgrounds and readable foreground/selection colors.
- Removes the `APPLICATIONS` and `REFERENCES` English micro-labels.
- Adds background presets: advanced dark gray, pure black, cool blue-gray, photo-background concept, and custom HEX color.
- Adds per-region panel opacity controls, plus a separate background-photo visibility slider.
- Background settings preview live and restore the previous colors, photo path, and opacity values if canceled.
- Static checks completed in this packaging environment: XAML parses successfully, removed labels are absent, C# delimiter counts are balanced, and the ZIP archive integrity test passes.
- **Not yet compiled or runtime-tested on Windows.** Extract into a new folder and run `build.cmd` on Windows 11; retain the previous version until this update is verified.
- Safety boundary unchanged: this update does not hide native desktop icons, modify registry state, move/overwrite/delete real files, or perform deep desktop embedding.


## V0.7.2 toolbar spacing and cleanup

- Based on the V0.7 source package, not the V0.8 layout experiment.
- Removed two obsolete fields reported by the previous Windows build as CS0169.
- Removed the extra helper line inside new partitions.
- Added a theme-colored toolbar background band and balanced vertical spacing around the toolbar, accounting for the neon glow; the spacing remains balanced when the neon is switched off.
- Static checks are available in the packaging notes; Windows compilation/runtime verification remains pending.
