@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0build.ps1"
set "BUILD_EXIT=%ERRORLEVEL%"
if not "%BUILD_EXIT%"=="0" (
  echo.
  echo Build failed. Keep this window open and send the full output.
  pause
  exit /b %BUILD_EXIT%
)
echo.
echo Build completed successfully.
pause
exit /b 0
