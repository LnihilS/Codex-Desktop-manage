@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0dist\App\DesktopOrganizer.App.exe" (
  call "%~dp0build.cmd"
  if errorlevel 1 exit /b %ERRORLEVEL%
)
if not exist "%~dp0dist\App\DesktopOrganizer.App.exe" (
  echo Main application executable was not found. Build may have failed.
  pause
  exit /b 1
)
start "Desktop Organizer" "%~dp0dist\App\DesktopOrganizer.App.exe"
