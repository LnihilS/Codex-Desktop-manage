using DesktopOrganizer.Core;

var passed = 0; var failed = 0;
void Test(string name, Action action)
{
    try { action(); passed++; Console.WriteLine($"PASS {name}"); }
    catch (Exception e) { failed++; Console.WriteLine($"FAIL {name}: {e}"); }
}
void Check(bool condition, string message = "assertion failed") { if (!condition) throw new Exception(message); }
void Equal(double a, double b) => Check(Math.Abs(a - b) < .01, $"expected {a:R}, got {b:R}");
DividerNode Leaf(string id, double w = 70, double h = 55) => new() { Id = id, MinWidth = w, MinHeight = h };
DividerNode Split(string id, DividerAxis axis, DividerNode a, DividerNode b, double ratio = .5) => new()
{ Id = id, Axis = axis, First = a, Second = b, Ratio = ratio, MinWidth = 0, MinHeight = 0 };
DividerNode Tree() => Split("main", DividerAxis.Horizontal,
    Split("upper", DividerAxis.Vertical,
        Split("nested", DividerAxis.Vertical, Leaf("apps"), Leaf("empty")), Leaf("todo"), .6),
    Split("lower", DividerAxis.Vertical, Leaf("refs"), Leaf("weather"), .6));
DividerLayout New(DividerNode? tree = null)
{
    var layout = new DividerLayout(tree ?? Tree(), new());
    Check(layout.Resize(1200, 800, out var error), error); return layout;
}
void Move(DividerLayout e, string id, double position) => Check(e.Move(id, position, out var error), error);

Test("legacy ratios migrate once", () =>
{
    var e = New(); Equal(720 - .5, e.State.Positions["upper"]);
    var before = new Dictionary<string, double>(e.State.Positions);
    Check(e.Resize(1200, 800, out _)); foreach (var (id, p) in before) Equal(p, e.State.Positions[id]);
});
Test("moving a parent preserves nested and lower global coordinates", () =>
{
    var e = New(); var nested = e.State.Positions["nested"]; var lower = e.State.Positions["lower"];
    Move(e, "upper", 900); Equal(nested, e.State.Positions["nested"]); Equal(lower, e.State.Positions["lower"]);
});
Test("moving nested splitter preserves all unrelated positions", () =>
{
    var e = New(); var before = new Dictionary<string, double>(e.State.Positions);
    Move(e, "nested", 450);
    foreach (var (id, p) in before.Where(k => k.Key != "nested")) Equal(p, e.State.Positions[id]);
});
Test("parent stops before nested minimum; no silent displacement", () =>
{
    var e = New(); var nested = e.State.Positions["nested"];
    Check(e.Move("upper", 0, out var reason)); Check(reason.Length > 0);
    Equal(nested + 75, e.State.Positions["upper"]); Equal(nested, e.State.Positions["nested"]);
});
Test("horizontal move preserves perpendicular lines and clamps nested horizontal line", () =>
{
    var tree = Split("h", DividerAxis.Horizontal,
        Split("inner-h", DividerAxis.Horizontal, Leaf("a"), Leaf("b")), Leaf("c"));
    var e = New(tree); var p = e.State.Positions["inner-h"];
    Move(e, "h", 0); Equal(p, e.State.Positions["inner-h"]); Equal(p + 60, e.State.Positions["h"]);
});
Test("near alignment produces exact pair candidate", () =>
{
    var e = New(); Move(e, "lower", e.State.Positions["upper"] + 8);
    var j = e.Junctions().Single(); Check(j.FirstId == "upper" && j.SecondId == "lower"); Check(!j.Linked);
});
Test("merge snaps true coordinates and moves exactly the selected group", () =>
{
    var e = New(); var nested = e.State.Positions["nested"]; var main = e.State.Positions["main"];
    Move(e, "lower", e.State.Positions["upper"] + 8);
    Check(e.Merge("upper", "lower", out var error), error);
    Equal(e.State.Positions["upper"], e.State.Positions["lower"]);
    Move(e, "lower", 850); Equal(850, e.State.Positions["upper"]); Equal(850, e.State.Positions["lower"]);
    Equal(nested, e.State.Positions["nested"]); Equal(main, e.State.Positions["main"]);
    Check(e.Junctions().Single().Linked);
});
Test("merged group obeys strictest boundary without skew", () =>
{
    var e = New(); Check(e.Merge("upper", "lower", out _));
    var nested = e.State.Positions["nested"];
    Check(e.Move("lower", -10000, out var reason)); Check(reason.Length > 0);
    Equal(e.State.Positions["upper"], e.State.Positions["lower"]); Equal(nested, e.State.Positions["nested"]);
});
Test("unmerge keeps positions, restores independence", () =>
{
    var e = New(); Check(e.Merge("upper", "lower", out _)); var p = e.State.Positions["upper"];
    Check(e.Unmerge("upper", "lower")); Equal(p, e.State.Positions["lower"]);
    Move(e, "lower", p + 100); Equal(p, e.State.Positions["upper"]); Check(e.State.Links.Count == 0);
});
Test("wrong orientation or non-adjacent segments cannot merge", () =>
{
    var e = New(); Check(!e.Merge("main", "upper", out _)); Check(!e.Merge("nested", "upper", out _));
    Check(e.State.Links.Count == 0);
});
Test("alignment beyond tolerance is refused", () =>
{
    var e = New(); Move(e, "lower", 1000); Check(!e.Merge("upper", "lower", out _));
});
Test("infeasible alignment is refused atomically", () =>
{
    var tree = Split("h", DividerAxis.Horizontal,
        Split("a", DividerAxis.Vertical, Leaf("l1"), Leaf("r1", 597.5)),
        Split("b", DividerAxis.Vertical, Leaf("l2", 600), Leaf("r2")));
    var e = New(tree); Move(e, "a", 599); Move(e, "b", 603);
    var before = new Dictionary<string, double>(e.State.Positions);
    Check(!e.Merge("a", "b", out var reason)); Check(reason.Length > 0);
    foreach (var (id, p) in before) Equal(p, e.State.Positions[id]); Check(e.State.Links.Count == 0);
});
Test("merge finds a common coordinate when first anchor is infeasible", () =>
{
    var tree = Split("h", DividerAxis.Horizontal,
        Split("a", DividerAxis.Vertical, Leaf("l1"), Leaf("r1")),
        Split("b", DividerAxis.Vertical, Leaf("l2", 600), Leaf("r2")));
    var e = New(tree); Move(e, "a", 599); Move(e, "b", 603);
    Check(e.Merge("a", "b", out var reason), reason);
    Equal(602.5, e.State.Positions["a"]); Equal(602.5, e.State.Positions["b"]);
});
Test("NaN/Infinity requests rejected", () =>
{
    var e = New(); Check(!e.Move("upper", double.NaN, out _)); Check(!e.Resize(double.PositiveInfinity, 800, out _));
});
Test("viewport resize preserves group equality and minimums", () =>
{
    var e = New(); Check(e.Merge("upper", "lower", out _));
    Check(e.Resize(500, 400, out var reason), reason);
    Equal(e.State.Positions["upper"], e.State.Positions["lower"]);
    foreach (var b in e.Boxes.Values) Check(b.Width >= 69.99 && b.Height >= 54.99);
});
Test("undersized viewport refused atomically", () =>
{
    var e = New(); Check(!e.Resize(10, 10, out _)); Equal(1200, e.State.Width); Equal(800, e.State.Height);
});
Test("atomic layout file save/load restores actual positions and group", () =>
{
    var temp = Path.Combine(Path.GetTempPath(), "DesktopOrganizerTests-" + Guid.NewGuid().ToString("N"));
    var path = Path.Combine(temp, "layout.json");
    try
    {
        var e = New(); Check(e.Merge("upper", "lower", out _)); Move(e, "upper", 890);
        var doc = new LayoutDocument { Dividers = e.State, Shortcuts = [new() { Name = "untouched", Path = "example.exe" }] };
        LayoutStore.Save(doc, path); var saved = LayoutStore.Load(path, out var warning); Check(warning is null);
        var restarted = new DividerLayout(Tree(), saved.Dividers!); Check(restarted.Resize(1200, 800, out _));
        foreach (var (id, p) in e.State.Positions) Equal(p, restarted.State.Positions[id]);
        Check(restarted.State.Links.Count == 1); Move(restarted, "lower", 940); Equal(940, restarted.State.Positions["upper"]);
        Check(saved.Shortcuts.Single().Name == "untouched");
        Check(restarted.Unmerge("upper", "lower")); LayoutStore.Save(saved, path);
        var unlinked = LayoutStore.Load(path, out _); Check(unlinked.Dividers!.Links.Count == 0);
        Check(Directory.GetFiles(temp).Length == 1);
    }
    finally { if (Directory.Exists(temp)) Directory.Delete(temp, true); }
});
Test("legacy JSON without divider state is readable", () =>
{
    var path = Path.Combine(Path.GetTempPath(), "layout-test-" + Guid.NewGuid().ToString("N") + ".json");
    try { File.WriteAllText(path, "{\"SchemaVersion\":1,\"UpperLeftColumnRatio\":0.7}");
        var doc = LayoutStore.Load(path, out var warning); Check(warning is null); Check(doc.Dividers is null); Equal(.7, doc.UpperLeftColumnRatio); }
    finally { File.Delete(path); }
});
Test("deleted IDs and links are removed, not rebound by index", () =>
{
    var e = New(); Check(e.Merge("upper", "lower", out _));
    var tree = Split("main", DividerAxis.Horizontal, Leaf("new-top"), Split("lower", DividerAxis.Vertical, Leaf("refs"), Leaf("weather")));
    var rebuilt = new DividerLayout(tree, e.State); Check(rebuilt.Resize(1200, 800, out _));
    Check(rebuilt.State.Links.Count == 0); Check(!rebuilt.State.Positions.ContainsKey("upper"));
});
Test("duplicate IDs are rejected", () =>
{
    var threw = false;
    try { _ = new DividerLayout(Split("duplicate", DividerAxis.Vertical, Leaf("duplicate"), Leaf("b")), new()); }
    catch (InvalidDataException) { threw = true; } Check(threw);
});
Test("three-segment chain: unlink one pair preserves other explicit pair", () =>
{
    var tree = Split("h1", DividerAxis.Horizontal, Split("v1", DividerAxis.Vertical, Leaf("a"), Leaf("b")),
        Split("h2", DividerAxis.Horizontal, Split("v2", DividerAxis.Vertical, Leaf("c"), Leaf("d")), Split("v3", DividerAxis.Vertical, Leaf("e"), Leaf("f"))));
    var e = New(tree); Check(e.Merge("v1", "v2", out _)); Check(e.Merge("v2", "v3", out _));
    Move(e, "v3", 800); Equal(800, e.State.Positions["v1"]); Equal(800, e.State.Positions["v2"]);
    Check(e.Unmerge("v1", "v2")); Move(e, "v2", 900); Equal(800, e.State.Positions["v1"]); Equal(900, e.State.Positions["v3"]);
});
Test("horizontal segments across a vertical separator merge and persist independently", () =>
{
    var tree = Split("v", DividerAxis.Vertical,
        Split("hl", DividerAxis.Horizontal, Leaf("a"), Leaf("b")),
        Split("hr", DividerAxis.Horizontal, Leaf("c"), Leaf("d")));
    var e = New(tree); Check(e.Junctions().Count == 1);
    var cross = e.State.Positions["v"];
    Check(e.Merge("hl", "hr", out var reason), reason); Move(e, "hr", 300);
    Equal(300, e.State.Positions["hl"]); Equal(cross, e.State.Positions["v"]);
    Check(e.Unmerge("hl", "hr")); Move(e, "hl", 200); Equal(300, e.State.Positions["hr"]);
});
Test("non-adjacent persisted links are refused instead of binding distant lines", () =>
{
    var e = New(); e.State.Links.Add(new("upper", "nested"));
    var reloaded = new DividerLayout(Tree(), e.State); Check(!reloaded.Resize(1200, 800, out _));
});
Test("300 random merged drags keep all other positions and continuous endpoints", () =>
{
    var e = New(); Check(e.Merge("upper", "lower", out _)); var random = new Random(38);
    var nested = e.State.Positions["nested"]; var main = e.State.Positions["main"];
    for (var i = 0; i < 300; i++)
    {
        Move(e, i % 2 == 0 ? "upper" : "lower", random.NextDouble() * 2000 - 400);
        Equal(e.State.Positions["upper"], e.State.Positions["lower"]);
        Equal(nested, e.State.Positions["nested"]); Equal(main, e.State.Positions["main"]);
        var joint = e.Junctions().Single(); Check(joint.Linked);
        var segments = e.Segments();
        Equal(5, segments.Single(s => s.Id == "lower").Start - segments.Single(s => s.Id == "upper").End);
    }
});
Test("2000 randomized drags never displace unrelated lines", () =>
{
    var e = New(); var random = new Random(42); var ids = e.State.Positions.Keys.ToArray();
    for (var i = 0; i < 2000; i++)
    {
        var id = ids[random.Next(ids.Length)]; var before = new Dictionary<string, double>(e.State.Positions);
        Move(e, id, random.NextDouble() * 2000 - 400);
        foreach (var (other, p) in before.Where(k => k.Key != id)) Equal(p, e.State.Positions[other]);
        foreach (var b in e.Boxes.Values) Check(b.Width >= 69.99 && b.Height >= 54.99);
    }
});
Console.WriteLine($"RESULT passed={passed} failed={failed}");
return failed == 0 ? 0 : 1;
