# Desktop Organizer 分割线修复候选版：实现与验证记录

**状态：源码修复、布局算法测试与 Windows 目标交叉编译已完成；Windows 实机构建和 WPF 交互验收未执行，不能称为任务全部完成。**

## 输入与范围

- 唯一输入源码：`DesktopOrganizerPrototype_V0.7.2_HeaderSpacingFix.zip`。
- 输入 ZIP SHA256：`b2cdf72813210d92cd0c184b7cb7bb4133e51112dd57f2c7d406550abde72b40`。
- 未收到 V0.7.3、V0.7.4、PRD V0.4 正文或用户实际 `layout.json`。依据本次消息中的行为和 DS-001 限制实现；不推断那些版本已包含什么修复。
- 保留应用快捷方式、待办、文件引用、天气、主题、字体、背景和原有桌面实验功能的源码。未运行桌面嵌入实验，未添加注册表写入、原生图标控制或真实文件搬移操作。
- 当前执行机器是 Linux，没有连接用户 Windows 电脑或可用远程桌面工具。上传源码不等于授予或建立 Windows 访问通道。

## 根因与旧逻辑

1. `BuildRegionVisual` 为每个递归分区建立独立 Grid，但两侧使用星号尺寸。子节点只保存 `Ratio`，不知道自身分割线在整个桌面区域中的绝对坐标。拖动祖先平行分割线时，后代所在 Grid 的宽高改变，后代线仍按局部比例重新分配，因而屏幕位置跟着移动。
   - 例如 1200 DIP 宽的布局，上方主竖线中心 719.5、其左侧嵌套竖线中心 358.5；主竖线移到 900 时，旧的 50% 嵌套线会移到 448.5。本次模型测试要求它仍为 358.5。
2. `Splitter_MouseLeftButtonUp` 读取 ActualWidth/ActualHeight，但保存时强制夹到 15%–85%。GridSplitter 的实际拖动边界是像素最小尺寸，并非这个比例区间。合法拖动结果可能被保存为另一个比例；重建/重启时又按夹紧比例重建，导致跳变。
3. 原保存只靠 `MouseLeftButtonUp`，没有独立的拖动事务和失去捕获/取消处理；内建 GridSplitter 的调整与业务保存并非统一提交。键盘调整也没有统一的保存路径。
4. 原“删除此分割线并合并分区”是删除树节点，不能表达两条线组成同步移动组。原文档没有合并 ID、候选交点或取消合并状态。
5. 本次检查未发现布局用的 Dispatcher 延迟回调或全局位置缓存。现有 Dispatcher 回调用于待办编辑框聚焦，不是这里的根因；未修改它。

## 真实控件、标识和坐标对应

| 控件 | 新稳定 ID | 父 Grid / 控制范围 |
| --- | --- | --- |
| `HorizontalSplitterMain` | `main:horizontal` | `DesktopGrid`，上、下分区 |
| `VerticalSplitterTop` | `main:upper-vertical` | `UpperRegionGrid`，常用应用、待办 |
| `VerticalSplitterBottom` | `main:lower-vertical` | `LowerRegionGrid`，文件引用、时间天气 |
| `CreateDynamicSplitter` 建立的控件 | `region:` + `RegionSplitNode.Id`，同时写入控件 `Uid` | `Tag = RegionSplitNode` 的递归 Grid，保留所属 rootKey |

`DividerLayout.Boxes` 给出每个树节点在 DesktopGrid 内的矩形；`Segments()` 给出每条线的方向、中心坐标和端点范围。候选交点来自这些实际布局节点，不按视觉索引猜测身份。没有用户保存的布局文件，因此不能列出用户实际新增线的 GUID 和实机坐标。

## 新行为

- 以 `LayoutDocument.Dividers` 存储 DesktopGrid 内的 DIP 中心坐标、上次视口宽高和明确的 ID 对关系。JSON SchemaVersion 仍为 1，新增字段可兼容读取旧布局；旧比例字段作为迁移输入和兼容输出保留。
- 鼠标预览事件在 GridSplitter 的内建 Thumb 改星号尺寸之前接管手势。方向键也走同一模型；Shift+方向键步进 10 DIP，普通方向键 1 DIP。
- 普通拖动只改变目标线的坐标；合并后只改变其显式连通组。布局矩形可重新测算，但无关线的中心状态保持不变。真实行列改成像素尺寸，仅对长度确有变化的定义赋值。
- 检查整个分区树的递归最小尺寸。目标越界时，当前线/组停在最近合法边界并显示原因；不通过移动其他线制造空间。
- 鼠标松开同步完成布局再保存。Escape 或失去鼠标捕获取消手势并恢复快照。拖动中其他控件触发的自动保存不会提交半成品。
- 保存前逐条读取控件在 DesktopGrid 中的实际中心；若与模型差异超过 0.05 DIP，明确报告并停止保存，避免将不一致数据写入磁盘。该 WPF 检查尚未实机运行。
- 两条同方向线中心距不超过 10 DIP、端点仅隔着一条真实的 5 DIP 垂直方向分割槽时，构成合并候选；不要求它们拥有同一个直接父 Grid。
- 编辑模式下，现有垂直方向分割槽的交点内显示 5×5 DIP 浅青亮点，右键选择合并。合并先求两组的共同合法坐标，再实际改变行列尺寸，最后记录 ID 关系；没有共同空间时明确拒绝。
- 交点控件只位于原有分割槽内，不新增覆盖窗口、桌面覆盖层或长线遮盖。合并后的两段真实线由同一位置约束驱动，交点控件仅填接已有 5 DIP 槽的交界。
- 右键已合并交点选择取消合并，移除指定 ID 对，保留当前位置。链式合并解除其中一对，不会解除其他明确关系。
- 删除分割线时清理该 ID 的坐标和关系，不把关系自动转绑给新线。旧“删除线合并分区”菜单仍保留，与“合并两段线”分开。
- 只有窗口尺寸变化、旧布局迁移或明确的树结构编辑才运行整体约束投影。窗口缩放可以使线条按视口缩放并满足最小尺寸；这与普通拖动保持其他线屏幕位置的要求不同。
- 重复 ID、非法合并关系或无法恢复的约束会阻止编辑/保存并给出状态提示，不悄悄重绑其他分割线。

## 实际执行与结果

执行平台：Linux x86_64（Debian 13），.NET SDK 10.0.402，MSBuild 18.9.15；项目目标 `net10.0-windows`。

CLI 初始化采用以下可写位置；未修改 HOME，也未禁用 TLS、包签名或校验：

```bash
export XDG_RUNTIME_DIR=/workspace/.dotnet-runtime  # 目录需存在，权限 700
export DOTNET_CLI_HOME=/workspace/.dotnet-home
export NUGET_PACKAGES=/workspace/.nuget/packages
export DOTNET_NOLOGO=1
```

最初环境为用户目录只读，.NET 10 的 NuGet 命名互斥锁无法建立。改用受支持的 `XDG_RUNTIME_DIR` 后构建正常；此问题不是项目编译错误。

| 检查 | 实际结果 | 日志 |
| --- | --- | --- |
| 原始 ZIP 解压副本的整个解决方案交叉编译 | 通过，0 警告、0 错误 | `validation/cloud/baseline-build.log` |
| 修改版首次交叉编译 | 失败：新增 partial 文件缺少 `System.IO`，CS0246；已修正 | `validation/cloud/fixed-build-initial-error.log`，保留完整错误 |
| 修改版最终解决方案交叉编译，警告视为错误 | 通过，0 警告、0 错误 | `validation/cloud/fixed-build.log` |
| Core 布局/磁盘保存回归测试 | **25 通过、0 失败**；未跳过 | `validation/cloud/layout-tests.log` |
| App 发布 `win-x64`（跨平台产生 Windows 目标文件） | 退出码 0 | `validation/cloud/publish-app.log` |
| Recovery 发布 `win-x64`（跨平台产生 Windows 目标文件） | 退出码 0 | `validation/cloud/publish-recovery.log` |
| Windows 机器上的原生 build.ps1 | **未执行** | 不能由交叉编译结果替代 |
| Windows 启动、鼠标/右键交互、视觉断口、DPI 与应用重启恢复 | **未执行** | 需要 Windows 会话 |

在两个项目根目录中，原始版和修改版各自实际运行的构建命令为：

```bash
/workspace/.dotnet/dotnet build DesktopOrganizerPrototype.sln -c Release -p:EnableWindowsTargeting=true --nologo -m:2
# 修改版最终构建额外加入 -warnaserror
/workspace/.dotnet/dotnet build DesktopOrganizerPrototype.sln -c Release -p:EnableWindowsTargeting=true --nologo -m:2 -warnaserror
/workspace/.dotnet/dotnet run --project tests/DesktopOrganizer.LayoutTests -c Release
/workspace/.dotnet/dotnet publish src/DesktopOrganizer.App/DesktopOrganizer.App.csproj -c Release -r win-x64 --self-contained false -p:EnableWindowsTargeting=true -warnaserror -o /workspace/desktop-validation/publish/App --nologo
/workspace/.dotnet/dotnet publish src/DesktopOrganizer.Recovery/DesktopOrganizer.Recovery.csproj -c Release -r win-x64 --self-contained false -p:EnableWindowsTargeting=true -warnaserror -o /workspace/desktop-validation/publish/Recovery --nologo
```

25 项测试链接并执行生产的 `DividerLayout.cs`、`Models.cs`、`LayoutStore.cs`、`AppDataPaths.cs`，没有用测试专用算法替代生产算法。包括 2000 次普通线随机拖动、300 次合并组随机拖动、横/竖方向、链式关系、非法对齐原子拒绝、共同合法位置、嵌套最小尺寸、删除 ID、旧 JSON、磁盘原子保存与重读。测试只操作随机临时目录，不读写用户默认 layout.json。

**这些测试不运行 WPF，也不证明窗口里的鼠标捕获、菜单命中和视觉效果已正确。**

## Windows 实机复验步骤（均待执行）

准备：Windows 11，官方 .NET 10 SDK / 对应桌面运行时。在普通可写目录解压。关闭原版应用；先手动备份 `%LOCALAPPDATA%\DesktopOrganizer\layout.json` 到你选择的位置。本脚本不自动覆盖、删除或移动该备份。

1. 在项目根目录 PowerShell 执行：
   ```powershell
   powershell -NoProfile -ExecutionPolicy Bypass -File .\verify-windows.ps1
   ```
   脚本依次记录 `dotnet --info`、整个解决方案 `-warnaserror` 构建、25 项回归测试、原有 `build.ps1` 发布。完整记录保存在 `validation-results/Windows-build-时间.log`。脚本**未在本云端运行**。
2. 执行 `run.cmd`；不要启动“深度嵌入实验”。验证普通窗口模式。
3. 按下列清单实际操作。只有实测后才填“通过”；发现异常时保留日志、layout.json 和复现步骤，继续调试。

| 实机验收项 | 具体操作 / 观察 | 当前状态 |
| --- | --- | --- |
| 两条默认竖线独立 | 进入编辑，拖上方竖线，确认下方位置不变；反向重复 | 未执行 |
| 嵌套平行线独立 | 常用应用区新增竖线，再拖上方主竖线；嵌套线保持屏幕 X 不变；向内拖到限制应停住并提示 | 未执行 |
| 嵌套横线独立 | 在上方区域新增横线，再拖主横线；嵌套横线保持 Y，达到最小高度时停止 | 未执行 |
| 交点亮斑 | 上下竖线拖到相差不超过 10 DIP，主横线处出现浅青亮点 | 未执行 |
| 合并 | 右键亮点→合并；两段准确对齐、交界无明显断口；拖任一段，另一段同步，无关线固定 | 未执行 |
| 取消合并 | 右键同一亮点→取消；位置不跳，之后可独立拖动 | 未执行 |
| 横向跨区合并 | 上方左右两个区域各新增横线，靠近同一 Y；在上方主竖线交点合并，验证相同行为 | 未执行 |
| 最小尺寸拒绝 | 制造两侧合法区间不相交的近似对齐，合并应提示失败，不新增关系、不移动其他线 | 未执行 |
| 保存并重启 | 移动并合并→完成编辑→正常退出→run.cmd；在相同窗口尺寸/DPI 下位置与关系应恢复；取消后重启亦应独立 | 未执行 |
| 手势取消 / 键盘 | 拖动中 Escape、切换窗口失去捕获，应恢复快照；方向键与 Shift+方向键能移动并保存 | 未执行 |
| 内容功能 | 快捷方式、待办顺序和编辑、文件引用、背景、主题、字体、天气正常；日常模式锁定分割线 | 未执行 |
| 显示缩放 | 100%/150%/200% DPI、最大化与还原；检查亮点命中、连续性和无保存不一致提示 | 未执行 |

## 修改文件清单

修改的原文件只有四份：

- `src/DesktopOrganizer.App/MainWindow.xaml.cs`：接入新控制器，移除旧保存事件，重建时注册/清理 ID，提交与保存保护，放宽旧的错误比例限制。
- `src/DesktopOrganizer.App/MainWindow.xaml`：仅去掉三个旧 MouseLeftButtonUp 绑定。
- `src/DesktopOrganizer.Core/Models.cs`：布局文档新增 Dividers 字段。
- `src/DesktopOrganizer.Core/LayoutStore.cs`：增加显式路径读写重载，便于真实磁盘保存测试隔离；默认布局路径不变，保留临时写入、Flush、校验后替换流程。

新增：

- `src/DesktopOrganizer.Core/DividerLayout.cs`：坐标状态、分割线/树节点身份、最小尺寸约束、移动与组关系、候选交点、视口迁移。
- `src/DesktopOrganizer.App/MainWindow.Dividers.cs`：真实 GridSplitter 的手势、行列尺寸更新、交点菜单、保存前实际中心校验。
- `tests/DesktopOrganizer.LayoutTests/DesktopOrganizer.LayoutTests.csproj`、`Program.cs`：25 项可独立运行的回归测试。
- `verify-windows.ps1`：Windows 原生构建/测试/发布记录脚本；不自动声称交互通过。
- `DIVIDER_FIX_REPORT.md`、`validation/cloud/*`：报告、完整日志、对原始四份文件的补丁。

其余上传文件保持字节一致。源码包不含 bin/obj、SDK、依赖缓存、真实用户数据或声称已验收的 Windows 程序。

剩余阻塞：没有 Windows 执行和交互通道。必须在 Windows 会话继续实际构建与交互验证，才能完成用户指定的最终验收。
