$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $root
if ($env:OS -ne 'Windows_NT') { throw 'This script must run on Windows. Cross-compilation is not Windows runtime validation.' }
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) { throw 'Install the official .NET 10 SDK first.' }
$logs = Join-Path $root 'validation-results'
New-Item -ItemType Directory -Force -Path $logs | Out-Null
$log = Join-Path $logs ('Windows-build-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.log')
Start-Transcript -Path $log -Force | Out-Null
try {
    Write-Host 'COMMAND: dotnet --info'
    & dotnet --info
    if ($LASTEXITCODE -ne 0) { throw 'dotnet --info failed.' }
    Write-Host 'COMMAND: dotnet build DesktopOrganizerPrototype.sln -c Release -warnaserror --nologo'
    & dotnet build DesktopOrganizerPrototype.sln -c Release -warnaserror --nologo
    if ($LASTEXITCODE -ne 0) { throw 'Windows solution build failed. The transcript contains the full errors.' }
    Write-Host 'COMMAND: dotnet run --project tests/DesktopOrganizer.LayoutTests -c Release'
    & dotnet run --project tests/DesktopOrganizer.LayoutTests -c Release
    if ($LASTEXITCODE -ne 0) { throw 'Layout regression tests failed. Do not treat this build as accepted.' }
    Write-Host 'COMMAND: .\build.ps1'
    & (Join-Path $root 'build.ps1')
    Write-Host 'Windows build/publish and geometry tests finished. INTERACTIVE ACCEPTANCE IS STILL PENDING.'
    Write-Host 'Next: run.cmd, then follow DIVIDER_FIX_REPORT.md. Record real interaction results in the checklist.'
} finally {
    Stop-Transcript | Out-Null
    Write-Host "Full transcript: $log"
}
