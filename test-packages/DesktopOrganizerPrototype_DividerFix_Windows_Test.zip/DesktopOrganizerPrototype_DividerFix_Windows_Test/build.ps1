$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $root

$dotnetCommand = Get-Command dotnet -ErrorAction SilentlyContinue
if (-not $dotnetCommand) {
    throw 'The .NET CLI was not found. Install the official .NET SDK and try again.'
}

$sdkList = & dotnet --list-sdks
if ($LASTEXITCODE -ne 0 -or -not $sdkList) {
    throw 'No .NET SDK was found. A runtime alone cannot build this project. Install a .NET SDK and try again.'
}

Write-Host 'Detected .NET SDKs:' -ForegroundColor Cyan
$sdkList | ForEach-Object { Write-Host "  $_" }

$dist = Join-Path $root 'dist'
$appOut = Join-Path $dist 'App'
$recoveryOut = Join-Path $dist 'Recovery'
New-Item -ItemType Directory -Force -Path $appOut, $recoveryOut | Out-Null

Write-Host ''
Write-Host 'Publishing the main application...' -ForegroundColor Cyan
& dotnet publish '.\src\DesktopOrganizer.App\DesktopOrganizer.App.csproj' -c Release -r win-x64 --self-contained false -o $appOut --nologo
if ($LASTEXITCODE -ne 0) {
    throw 'Publishing the main application failed. Keep the full terminal output and send it for diagnosis.'
}

Write-Host ''
Write-Host 'Publishing the recovery application...' -ForegroundColor Cyan
& dotnet publish '.\src\DesktopOrganizer.Recovery\DesktopOrganizer.Recovery.csproj' -c Release -r win-x64 --self-contained false -o $recoveryOut --nologo
if ($LASTEXITCODE -ne 0) {
    throw 'Publishing the recovery application failed. Keep the full terminal output and send it for diagnosis.'
}

Write-Host ''
Write-Host 'Publish completed.' -ForegroundColor Green
Write-Host "Main application: $appOut\DesktopOrganizer.App.exe"
Write-Host "Recovery application: $recoveryOut\DesktopOrganizer.Recovery.exe"
Write-Host 'This script does not install services, register startup tasks, edit the registry, or hide desktop icons.'
