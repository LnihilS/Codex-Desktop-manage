$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$app = Join-Path $root 'dist\App\DesktopOrganizer.App.exe'

if (-not (Test-Path -LiteralPath $app)) {
    & (Join-Path $root 'build.ps1')
}

if (-not (Test-Path -LiteralPath $app)) {
    throw 'The main application was not produced. Review the build output and try again.'
}

Start-Process -FilePath $app
