# Desktop Organizer Prototype V0.3 — layout iteration

This is an incremental source update to the Windows 11 WPF prototype. It keeps the existing shortcut, file-reference, todo, background, clock/weather entry, recovery, and safe-mode features while improving layout editing.

## Build on Windows

1. Extract this ZIP to a normal writable folder.
2. Double-click `build.cmd`, or open PowerShell in that folder and run `.\build.cmd`.
3. After `Build completed successfully.`, run `run.cmd`.

The project targets `net10.0-windows` and needs a compatible .NET SDK. The build script uses process-scoped PowerShell execution-policy bypass; it does not change the machine-wide policy.

## Changes in V0.3

- Upper and lower regions now have independent vertical splitters and save their ratios separately.
- In edit mode, right-click a region to add a horizontal or vertical split. Drag the new divider to resize it; right-click the divider to merge it back. Split trees and ratios are saved in the local layout JSON.
- Added a global font-size dialog (80%–160%) with persistence.
- Replaced the light native title bar with a dark custom title bar and minimize, maximize/restore, and close buttons.
- Increased the neon bar height and made its gradient animation span a wider range.
- Existing region content remains in place when a new split is added. The merge action refuses to discard content if both sides are populated.

## Safety and verification status

- The package has **not** been compiled or run on Windows by the packaging environment. Re-run `build.cmd` on the target Windows PC and send the full output if it fails.
- Do not use the deep desktop embedding experiment until the ordinary UI is verified. This iteration does not hide native desktop icons, edit the registry, or move/overwrite/delete real files.
- Weather data, full component drag-and-drop between regions, arbitrary populated-region merge, installer/startup registration, and Gate B desktop embedding tests remain future work.


## V0.3 本轮改动

主窗口不再显示顶部标题栏；在左上方品牌区域拖动可移动窗口，双击可切换最大化。右侧工具栏提供“霓虹设置”“字体设置”和“退出”。霓虹设置可分别调节长度百分比与粗细；字体设置按类别独立调整并实时预览。用户指定的四处说明/标题文字已删除。

请在 Windows 上运行 `build.cmd` 后再用 `run.cmd` 验证。当前生成环境未运行 Windows WPF 编译；构建成功后再测试界面。深度嵌入和原生图标控制仍应暂缓。


## V0.4 背景与可读性更新

- 在“背景与透明度”中选择深灰、纯黑、深蓝灰或照片背景概念，也可输入自定义 HEX 色值。
- 可按全部分区或单独分区调整底色不透明度，并单独调节照片可见度。
- 字体设置下拉列表使用深色样式；已移除 APPLICATIONS / REFERENCES 英文副标题。
- 建议在 Windows 11 上运行 `build.cmd` 后再运行 `run.cmd`。当前包尚未通过 Windows 实机编译验收。


## V0.5 可用性修复

- 主窗口默认以最大化状态启动。
- 背景设置下拉框改用完整的深色控件模板，避免浅色选中框上出现白字。
- 待办事项完成状态不再触发自动排序，保持当前列表位置。
- 常用应用支持鼠标拖动到另一快捷方式上进行排序；排序会保存到本地布局。
- 本包尚未在 Windows 实机编译或运行。请运行 `build.cmd` 后再运行 `run.cmd`。


## V0.6：下拉框、标题拖动与 MSN 天气

- 两个背景设置下拉框会显示中文选项名称，不再显示 C# 类型全名。
- 进入编辑模式后，可拖动“常用应用”标题，并自动保存位置。
- 天气区域嵌入用户提供的 MSN 双流区天气页面；可刷新、切换城市或在 Edge 中打开。
- 构建需要联网下载 `Microsoft.Web.WebView2` NuGet 包；运行需要 WebView2 Runtime。
- 尚未进行 Windows 实机编译和运行验证。


## V0.7：独立天气卡片与通用可编辑标题

- 天气区域使用自绘天气卡片，显示温度、天气状况、最高/最低温、体感、湿度、风速和未来小时预报；MSN 页面只作为参考页入口。
- 天气数据通过 Open-Meteo 的公开天气与地理编码 API 获取，不再嵌入完整 MSN 页面。
- 现有分区标题支持编辑模式下拖动和双击改名；新建空白分区默认带“新分区”标题。
- 标题文字与位置会保存在本地布局中。
- 已做静态结构检查，仍需在 Windows 上构建与运行验证。


## V0.7.2 — toolbar spacing and cleanup

- Removed two obsolete application-title drag fields that produced CS0169 warnings.
- Removed the extra instructional line shown inside newly created partitions; the partition title and right-click split menu remain.
- Added a theme-colored toolbar background band. The toolbar's top spacing accounts for the neon glow and matches the bottom spacing; when neon is disabled, the neon row collapses and the toolbar uses equal top/bottom spacing.
- Updated the visible prototype badge to V0.7.2.

**Verification status:** source and XML static checks completed. This package has not been compiled or run on Windows in the packaging environment. Build on the Windows PC with `build.cmd`; keep V0.7 available until the new build is verified.
